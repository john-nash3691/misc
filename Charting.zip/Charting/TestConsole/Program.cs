﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Reflection.Metadata;
using System.Runtime.InteropServices;
using ChartLib;
using CsvHelper;
using CsvHelper.Configuration.Attributes;
using DataLib;
using LiteDB;
using Newtonsoft.Json;
using TestConsole.Extensions;
using BaseSeriesItem = DataLib.BaseSeriesItem;
using Query = LiteDB.Query;

namespace TestConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            var liteDb = new LiteDatabase("D:\\Temp\\DataFile.db");
            var coll = liteDb.GetCollection<ServerLog>();

            //var lst1 = new List<string>() { "A1", "B1", "D1", "C1", "E1" };
            //var lst2 = new List<string>() { "A1", "C1", }.ToDictionary(x => x, x => x.Length);
            //var dt = from xkey in lst1
            //         join curxkey in lst2 on xkey.ToLower() equals curxkey.Key.ToLower() into jp
            //         from jpItem in jp.DefaultIfEmpty()
            //         select new { xkey, val = string.IsNullOrEmpty(jpItem.Key) ? 0 : jpItem.Value };

            //foreach (var item in dt)
            //{
            //    Console.WriteLine($"{item.xkey}, {item.val}");
            //}

            //var lk = coll.Find(Query.EQ("EVENTID", "BAS_0001")).ToList();
            var lk = coll.FindAll().Take(10).ToList();
            var bd = lk.WithData().ForX(x => x.AGENT).ForY(x => x.APPNAME);
            //PrintList(bd.XCategories());
            var dyn = bd.Group().Select(x => new
            {
                name = x.Key,
                data = x.Value
            });

            Console.WriteLine("XCategories");
            Console.WriteLine(JsonConvert.SerializeObject(bd.XCategories()));
            Console.WriteLine("YCategories");
            Console.WriteLine(JsonConvert.SerializeObject(bd.YCategories()));
            File.WriteAllText(@"D:\Temp\out_d.json", JsonConvert.SerializeObject(dyn, Formatting.Indented));

            //using (var reader = new StreamReader("D:\\SourceCode\\TFS_NIKX\\office-src\\Charting\\ServerLogs.csv"))
            //using (var csv = new CsvReader(reader))
            //{
            //    var records = csv.GetRecords<ServerLog>().ToList();
            //    records.ForEach(x => x.Id = ObjectId.NewObjectId().ToString());
            //    coll.Insert(records);
            //}


            //var tick = DateTimeOffset.Now.ToUnixTimeSeconds();
            //var str = DateTime.Now.AddHours(5).ToString("MM/dd/yyyy hh:mm");

            //// var dt = DateTime.TryParse("4/15/2019 3:16", out DateTime ds);
            //var dt = DateTime.ParseExact("04/15/2019 03:16", new[] { "M/dd/yyyy h:mm", "M/dd/yyyy hh:mm" , "MM/dd/yyyy hh:mm", "MM/dd/yyyy h:mm" }, null);

            //// new DataStore().ReadLogs(@"D:\SourceCode\GIT_NIKX\util\util-protector\assets\ServerLogs.csv");
            //var query = new Query(new DataStore());

            ////var data = query.Db.GetCollection<ServerLog>().FindAll().Where(x => x.Node == "wrvra01a0896");
            //var data = query.Db.GetCollection<ServerLog>().FindAll().GroupBy(x => x.AppId).Where(x => x.Count() > 1);

            //foreach (var serverLog in data.First())
            //{
            //    Console.WriteLine($"{serverLog.AppId}, {serverLog.AppName}, {serverLog.AssetCity}, {serverLog.FirstOccurence}");
            //}


            Console.WriteLine("Hello World!");
        }

        static void PrintList(List<string> data)
        {
            for (int i = 0; i < data.Count; i++)
            {
                Console.WriteLine(data[i]);
            }
        }

        static void PrintList(List<int> data)
        {
            for (int i = 0; i < data.Count; i++)
            {
                Console.WriteLine(data[i]);
            }
        }
    }



    public class BarChartData<T>
    {
        private List<T> _data;
        private LambdaExpression _xProp;
        private LambdaExpression _yProp;
        public BarChartData(List<T> data)
        {
            _data = data;
        }

        public BarChartData<T> ForX<TValue>(Expression<Func<T, TValue>> expression)
        {
            _xProp = expression;
            return this;
        }

        public BarChartData<T> ForY<TValue>(Expression<Func<T, TValue>> expression)
        {
            _yProp = expression;
            return this;
        }

        public List<string> XCategories()
        {
            var val = _xProp.Compile() as Func<T, string>;
            return _data.Select(val).Distinct(StringComparer.InvariantCultureIgnoreCase).ToList();
        }

        public List<string> YCategories()
        {
            var val = _yProp.Compile() as Func<T, string>;
            return _data.Select(val).Distinct(StringComparer.InvariantCultureIgnoreCase).ToList();
        }

        public Dictionary<string, int[]> Group()
        {
            var xAxis = _yProp.Compile() as Func<T, string>;
            var yAxis = _xProp.Compile() as Func<T, string>;
            var grpY = _data.Where(x => !string.IsNullOrEmpty(yAxis(x))).GroupBy(x => yAxis(x));
            var lstXAxis = _data.Where(x => !string.IsNullOrEmpty(xAxis(x))).Select(x => xAxis(x).ToLower()).Distinct().ToList();
            var barData = new Dictionary<string, int[]>(StringComparer.InvariantCultureIgnoreCase);
            var barData2 = new Dictionary<string, Dictionary<string, int>>(StringComparer.InvariantCultureIgnoreCase);

            foreach (var item in grpY)
            {
                var curXAxisGrp = item.Where(x => !string.IsNullOrEmpty(xAxis(x))).GroupBy(x => xAxis(x).ToLower());
                var dt = (from xAxisItem in lstXAxis
                          join xAxisGrpItem in curXAxisGrp on xAxisItem equals xAxisGrpItem.Key into jp
                          from jpItem in jp.DefaultIfEmpty()
                          select jpItem?.Count() + 1 ?? 1).ToArray();
                barData.Add(item.Key, dt);
                barData2.Add(item.Key, curXAxisGrp.ToDictionary(x => x.Key, y => y.Count()));
            }

            return barData;
        }
    }

    public class ChartMember<T, TProp>
    {
        private readonly BarChartData<T> _data;
        private readonly Func<T, TProp> _func;

        public ChartMember(BarChartData<T> data, Func<T, TProp> func)
        {
            _data = data;
            _func = func;
        }
    }

    public class ServerLog
    {
        [Ignore]
        public string Id { get; set; }
        public string NODE { get; set; }
        public string AGENT { get; set; }
        public string EVENTID { get; set; }
        public string COMPONENTNAME { get; set; }
        public string ALERTGROUP { get; set; }
        public string ALERTKEY { get; set; }
        public string ORIGINALSEVERITY { get; set; }
        public string FIRSTOCCURRENCE { get; set; }
        public string LASTOCCURRENCE { get; set; }
        public string APPID { get; set; }
        public string APPNAME { get; set; }
        public string ASSETID { get; set; }
        public string ASSETCITY { get; set; }
        public string ASSETLOCATION { get; set; }
        public string ASSETOPSYS { get; set; }
        public string ASSETROLE { get; set; }
        public string ASSETSERVERFUNCTION { get; set; }
        public string ASSETSGAPP { get; set; }
        public string ASSETSGAPPSERVER { get; set; }
        public string ASSETSGDB { get; set; }
        public string ASSETSGHARDWARE { get; set; }
        public string ASSETSGLOB { get; set; }
        public string ASSETSGPRIMARY { get; set; }
        public string ASSETSGSAN { get; set; }
        public string ASSETSGVIRTUALSERVER { get; set; }
        public string ASSETSTATE { get; set; }
        public string ASSETSTATUS { get; set; }
        public string ASSETMAC { get; set; }
        public string ASSETSGBACKUP { get; set; }
        public string ASSETSGMW { get; set; }
        public string EMAIL { get; set; }
        public string PAGE { get; set; }
        public string REMEDYTICKETID { get; set; }
        public string REMEDYPLATFORM { get; set; }
        public string REMEDYCATEGORY { get; set; }
        public string REMEDYOWNERGROUP { get; set; }
        public string REMEDYRESPONSIBLEGROUP { get; set; }
        public string SUMMARY { get; set; }
    }
}

namespace TestConsole.Extensions
{
    public static class BarChartExtensions
    {
        public static BarChartData<T> WithData<T>(this List<T> data)
        {
            return new BarChartData<T>(data);
        }

        //public static BarChartData<T> ForX<T>(this BarChartData<T> data)
        //{
        //    return data;
        //}
    }
}
