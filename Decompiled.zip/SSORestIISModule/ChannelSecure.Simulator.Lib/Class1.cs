﻿using System;

namespace ChannelSecure.Simulator.Lib
{
    public class Class1
    {
    }
}
