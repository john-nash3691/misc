﻿using System.Collections.Generic;

namespace ChannelSecure.Simulator.Lib.Gateway
{
  public class SubRequest
  {
    public Dictionary<string, string[]> Headers { get; set; }

    public List<JavaCookie> Cookies { get; set; }
  }
}
