﻿namespace ChannelSecure.Simulator.Lib.Gateway
{
  public class GatewayResponse
  {
    public SubRequest Request { get; set; }

    public SubResponse Response { get; set; }
  }
}
