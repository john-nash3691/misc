﻿
namespace ChannelSecure.Simulator.Lib.Gateway
{
  public class GatewayResponseMessage
  {
    public GatewayResponse Response { get; set; }

    public int StatusCode { get; set; }
  }
}
