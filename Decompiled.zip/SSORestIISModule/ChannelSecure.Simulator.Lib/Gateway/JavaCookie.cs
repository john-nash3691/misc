﻿using Newtonsoft.Json;

namespace ChannelSecure.Simulator.Lib.Gateway
{
  public class JavaCookie
  {
    [JsonProperty(PropertyName = "name")]
    public string Name { get; set; }

    [JsonProperty(PropertyName = "value")]
    public string Value { get; set; }

    [JsonProperty(PropertyName = "maxAge")]
    public long MaxAge { get; set; }

    [JsonProperty(PropertyName = "secure")]
    public bool Secure { get; set; }

    [JsonProperty(PropertyName = "version")]
    public int Version { get; set; }

    [JsonProperty]
    public string Domain { get; set; }

    [JsonProperty(PropertyName = "Httponly")]
    public bool HttpOnly { get; set; }
  }
}
