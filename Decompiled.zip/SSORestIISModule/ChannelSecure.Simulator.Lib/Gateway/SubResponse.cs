﻿using System.Collections.Generic;

namespace ChannelSecure.Simulator.Lib.Gateway
{
  public class SubResponse
  {
    public int Status { get; set; }

    public Dictionary<string, string[]> Headers { get; set; }

    public List<JavaCookie> Cookies { get; set; }

    public string Body { get; set; }
  }
}
