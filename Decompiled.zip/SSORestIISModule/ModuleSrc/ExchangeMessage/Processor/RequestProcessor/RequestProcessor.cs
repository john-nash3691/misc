﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using SSORestIISModule.Core.Common.Gateway;
using SSORestIISModule.Core.Common.Log.Enum;
using SSORestIISModule.Core.Common.Module;
using SSORestIISModule.Core.Common.Utility;
using SSORestIISModule.Core.Configuration;
using SSORestIISModule.Core.InternalLogger;
using SSORestIISModule.ExchangeMessage.Processor.ResponseProcessor;
using System;
using System.Collections.Generic;
using System.Threading;

namespace SSORestIISModule.ExchangeMessage.Processor.RequestProcessor
{
  internal sealed class RequestProcessor : AbstractModule, IRequestProcessor, IDisposable
  {
    private bool _disposed;
    private long _startTime;
    private int _responseGatewayStatusCode;
    private readonly bool _isEnable;
    private readonly Lazy<IgnorePattern> _ignorePattern;
    private readonly IResponseProcessor _gatewayResponseProcessor;

    public RequestProcessor()
    {
    }

    public RequestProcessor(IResponseProcessor responseProcessor)
    {
      this._isEnable = this.ConfigParam.Enabled;
      this._gatewayResponseProcessor = responseProcessor;
      this._ignorePattern = new Lazy<IgnorePattern>((Func<IgnorePattern>) (() => new IgnorePattern(this.ConfigParam.IgnoreExtName, this.ConfigParam.IgnoreUrlName, this.ConfigParam.IgnoreHostName)));
    }

    public void ContextOnBeginRequest(HttpContext context)
    {
      if (!this._isEnable || this._ignorePattern.Value.CheckIfIgnored(new Uri(UriHelper.GetDisplayUrl(context.Request))))
        return;
      Interlocked.Exchange(ref this._startTime, DateTime.UtcNow.Ticks);
      try
      {
        this._responseGatewayStatusCode = this._gatewayResponseProcessor.Processor(context);
      }
      catch (ThreadAbortException ex)
      {
        this.LogProvider.LogWrite((Exception) ex, ex.ToString(), LogSeverity.Error);
        throw;
      }
      catch (Exception ex)
      {
        this.LogProvider.LogWrite(ex, ex.ToString(), LogSeverity.Error);
        throw;
      }
      finally
      {
        long totalMilliseconds = (long) (new TimeSpan(DateTime.UtcNow.Ticks) - new TimeSpan(this._startTime)).TotalMilliseconds;
        Uri uri = new Uri(UriHelper.GetDisplayUrl(context.Request));
        if (this.ConfigParam.TransactionTimeWarningThreshold > 0L && totalMilliseconds >= this.ConfigParam.TransactionTimeWarningThreshold)
        {
          if (this._responseGatewayStatusCode > 0)
          {
            ILogProvider logProvider = this.LogProvider;
            object[] objArray = new object[8]
            {
              (object) this._responseGatewayStatusCode,
              (object) totalMilliseconds,
              (object) context.Connection.RemoteIpAddress,
              (object) context.Connection.LocalIpAddress.ToString(),
              (object) context.Request.Method,
              (object) uri.AbsolutePath,
              (object) context.Request.Protocol,
              null
            };
            HostString host = context.Request.Host;
            objArray[7] = host.Host;
            string message = string.Format("Request to Gateway had result code {0} ({1} ms), client: {2}, server: {3}, request: \"{4} {5} {6}\", host: \"{7}\"", objArray);
            logProvider.LogWrite(message, LogSeverity.Warn);
          }
          else
          {
            ILogProvider logProvider = this.LogProvider;
            object[] objArray = new object[7]
            {
              (object) totalMilliseconds,
              (object) context.Connection.RemoteIpAddress.ToString(),
              (object) context.Connection.LocalIpAddress.ToString(),
              (object) context.Request.Method,
              (object) uri.AbsolutePath,
              (object) context.Request.Protocol,
              null
            };
            HostString host = context.Request.Host;
            objArray[6] = (object) host.Host;
            string message = string.Format("Request to Gateway had ({0} ms), client: {1}, server: {2}, request: \"{3} {4} {5}\", host: \"{6}\"", objArray);
            logProvider.LogWrite(message, LogSeverity.Warn);
          }
        }
        else if (this._responseGatewayStatusCode > 0)
        {
          ILogProvider logProvider = this.LogProvider;
          object[] objArray = new object[8]
          {
            (object) this._responseGatewayStatusCode,
            (object) totalMilliseconds,
            (object) context.Connection.RemoteIpAddress.ToString(),
            (object) context.Connection.LocalIpAddress.ToString(),
            (object) context.Request.Method,
            (object) uri.AbsolutePath,
            (object) context.Request.Protocol,
            null
          };
          HostString host = context.Request.Host;
          objArray[7] = (object) host.Host;
          string message = string.Format("Request to Gateway had result code {0} ({1} ms), client: {2}, server: {3}, request: \"{4} {5} {6}\", host: \"{7}\"", objArray);
          logProvider.LogWrite(message, LogSeverity.Info);
        }
        else
        {
          ILogProvider logProvider = this.LogProvider;
          object[] objArray = new object[7]
          {
            (object) totalMilliseconds,
            (object) context.Connection.RemoteIpAddress.ToString(),
            (object) context.Connection.LocalIpAddress.ToString(),
            (object) context.Request.Method,
            (object) uri.AbsolutePath,
            (object) context.Request.Protocol,
            null
          };
          HostString host = context.Request.Host;
          objArray[6] = (object) host.Host;
          string message = string.Format("Request to Gateway had ({0} ms), client: {1}, server: {2}, request: \"{3} {4} {5}\", host: \"{6}\"", objArray);
          logProvider.LogWrite(message, LogSeverity.Info);
        }
        Interlocked.Exchange(ref this._startTime, 0L);
      }
    }

    public void PreSendRequestHeaders(HttpContext context)
    {
      if (!context.Items.ContainsKey((object) "idf_100cookies"))
        return;
      IEnumerable<JavaCookie> cookies = (IEnumerable<JavaCookie>) context.Items[(object) "idf_100cookies"];
      HttpResponse response = context.Response;
      HostString host1 = context.Request.Host;
      string host2 = host1.Host;
      Utils.FillCookiesForResponseContext(cookies, response, host2);
    }

    public void Dispose()
    {
      this.Dispose(true);
      GC.SuppressFinalize((object) this);
    }

    private void Dispose(bool disposing)
    {
      if (this._disposed)
        return;
      if (disposing)
        this._ignorePattern?.Value.Dispose();
      this._disposed = true;
    }

    ~RequestProcessor()
    {
      this.Dispose(false);
    }
  }
}
