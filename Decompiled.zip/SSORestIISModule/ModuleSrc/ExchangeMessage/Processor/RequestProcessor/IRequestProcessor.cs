﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.ExchangeMessage.Processor.RequestProcessor.IRequestProcessor
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using Microsoft.AspNetCore.Http;

namespace SSORestIISModule.ExchangeMessage.Processor.RequestProcessor
{
  public interface IRequestProcessor
  {
    void ContextOnBeginRequest(HttpContext context);

    void PreSendRequestHeaders(HttpContext context);

    void Dispose();
  }
}
