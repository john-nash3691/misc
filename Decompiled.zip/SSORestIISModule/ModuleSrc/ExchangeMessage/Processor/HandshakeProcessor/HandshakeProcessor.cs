﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.ExchangeMessage.Processor.HandshakeProcessor.HandshakeProcessor
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using Microsoft.AspNetCore.Http;
using SSORestIISModule.Core.Common.Gateway;
using SSORestIISModule.Core.Common.Http;
using SSORestIISModule.Core.Common.Log.Enum;
using SSORestIISModule.Core.Common.Module;
using SSORestIISModule.Core.Common.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace SSORestIISModule.ExchangeMessage.Processor.HandshakeProcessor
{
  internal class HandshakeProcessor : AbstractModule, IHandshakeProcessor
  {
    public string DecoderResponse(HttpContext context, GatewayResponse gatewayResponse)
    {
      string empty = string.Empty;
      try
      {
        empty = Encoding.UTF8.GetString(Convert.FromBase64String(gatewayResponse.Response.Body));
      }
      catch (ArgumentNullException ex)
      {
        this.LogProvider.LogWrite("Dirty hack to FOR COMPATABILITY WITH 2.15.1 : Empty JSON response body", LogSeverity.Debug);
      }
      catch (FormatException ex)
      {
        if (!gatewayResponse.Response.Body.Contains("Signature Needed"))
        {
          this.LogProvider.LogWrite("Dirty hack to FOR COMPATABILITY WITH 2.15.1 : JSON response body isn't base64-encoded and also doesn't contain \"Signature Needed\" substring", LogSeverity.Error);
          context.Response.HttpContext.Abort();
        }
      }
      return empty;
    }

    public void Handshake(HttpContext context)
    {
      if (string.IsNullOrEmpty(this.ConfigParam.SecretKeyName))
        this.LogProvider.LogWrite("Filter's Secret key is not defined", LogSeverity.Warn);
      if (string.IsNullOrEmpty(this.ConfigParam.PluginIdName))
        this.LogProvider.LogWrite("Plugin ID is not defined", LogSeverity.Warn);
      try
      {
        string secretKeyName = this.ConfigParam.SecretKeyName;
        string pluginIdName = this.ConfigParam.PluginIdName;
        string lowerInvariant = Utils.GetRandomString(32).ToLowerInvariant();
        string str = HttpUtility.UrlEncode(Utils.HmacBase64(lowerInvariant, Encoding.UTF8.GetBytes(secretKeyName)), Encoding.UTF8);
        AttributesManager.SetAttribute(context, "pluginID", pluginIdName);
        AttributesManager.SetAttribute(context, "randomText", lowerInvariant);
        AttributesManager.SetAttribute(context, "randomTextSigned", str);
      }
      catch
      {
        this.LogProvider.LogWrite("ERROR generating signature", LogSeverity.Error);
        context.Response.HttpContext.Abort();
      }
    }

    public void Handshake3(HttpContext context, GatewayResponse gatewayResponse)
    {
      Dictionary<string, string[]> headers = gatewayResponse.Response.Headers;
      string[] strArray = headers != null ? headers.FirstOrDefault<KeyValuePair<string, string[]>>((Func<KeyValuePair<string, string[]>, bool>) (d => d.Key.Equals("Challenge", StringComparison.OrdinalIgnoreCase))).Value : (string[]) null;
      if (strArray == null || strArray.Length == 0)
        this.LogProvider.LogWrite("Not able to get challenge from Gateway.No challenge response will be sent", LogSeverity.Warn);
      if (string.IsNullOrEmpty(this.ConfigParam.SecretKeyName))
        this.LogProvider.LogWrite("Filter's Secret key is not defined", LogSeverity.Warn);
      if (string.IsNullOrEmpty(this.ConfigParam.PluginIdName))
        this.LogProvider.LogWrite("Plugin ID is not defined", LogSeverity.Warn);
      try
      {
        string str = HttpUtility.UrlEncode(Utils.HmacBase64(strArray[0], Encoding.UTF8.GetBytes(this.ConfigParam.SecretKeyName)), Encoding.UTF8);
        string pluginIdName = this.ConfigParam.PluginIdName;
        AttributesManager.SetAttribute(context, "pluginID", pluginIdName);
        AttributesManager.SetAttribute(context, "randomText", strArray[0]);
        AttributesManager.SetAttribute(context, "randomTextSigned", str);
      }
      catch
      {
        this.LogProvider.LogWrite("ERROR generating signature", LogSeverity.Error);
        context.Response.HttpContext.Abort();
      }
    }
  }
}
