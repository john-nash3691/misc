﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.ExchangeMessage.Processor.HandshakeProcessor.IHandshakeProcessor
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using Microsoft.AspNetCore.Http;
using SSORestIISModule.Core.Common.Gateway;

namespace SSORestIISModule.ExchangeMessage.Processor.HandshakeProcessor
{
  public interface IHandshakeProcessor
  {
    void Handshake(HttpContext context);

    void Handshake3(HttpContext context, GatewayResponse gatewayResponse);

    string DecoderResponse(HttpContext context, GatewayResponse gatewayResponse);
  }
}
