﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.ExchangeMessage.Processor.ResponseProcessor.ResponseProcessor
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Primitives;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using SFTIHM.Filter_dotnetcore;
using SSORestIISModule.Core.Common.Gateway;
using SSORestIISModule.Core.Common.Http;
using SSORestIISModule.Core.Common.Log.Enum;
using SSORestIISModule.Core.Common.Module;
using SSORestIISModule.Core.Common.Utility;
using SSORestIISModule.Core.ConnectionPool;
using SSORestIISModule.ExchangeMessage.Processor.HandshakeProcessor;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SSORestIISModule.ExchangeMessage.Processor.ResponseProcessor
{
  public class ResponseProcessor : AbstractModule, IResponseProcessor
  {
    private volatile bool _is510Request;
    private string _gatewayToken;
    private readonly IGatewayConnectionPool _gatewayConnectionPool;
    private readonly IRequestFactory _gatewayRequestFactory;
    private readonly IHandshakeProcessor _gatewayHandshakeProcessor;

    public ResponseProcessor(
      IGatewayConnectionPool connectionPool,
      IHandshakeProcessor handshakeProcessor,
      IRequestFactory requestFactory)
    {
      this._gatewayConnectionPool = connectionPool;
      this._gatewayHandshakeProcessor = handshakeProcessor;
      this._gatewayRequestFactory = requestFactory;
    }

    public int Processor(HttpContext context)
    {
      return this.GatewayProcessing(context);
    }

    private int GatewayProcessing(HttpContext context)
    {
      AttributesManager.SetAttribute(context, "acoName", this.ConfigParam.SsorestAcoName);
      AttributesManager.SetAttribute(context, "gatewayToken", this._gatewayToken);
      AttributesManager.SetAttribute(context, "pluginID", this.ConfigParam.PluginIdName);
      GatewayResponseMessage result = this.RetryAsync(new Func<HttpContext, string, GatewayResponseMessage>(this.GetResponseFromGateway), context, this.ConfigParam.MaxRetries, this.ConfigParam.RetriesDelay, this._is510Request).ConfigureAwait(false).GetAwaiter().GetResult();
      if (result != null)
      {
        this.LogProvider.LogWrite(string.Format("Request response. Status {0} {1} {2}", (object) result.Response.Response.Status, (object) context.Request.Method, (object) UriHelper.GetDisplayUrl(context.Request)), LogSeverity.Info);
        if (result.Response.Response.Headers != null && result.Response.Response.Headers.ContainsKey("gatewayToken") && !string.IsNullOrEmpty(((IEnumerable<string>) result.Response.Response.Headers["gatewayToken"]).FirstOrDefault<string>()))
          this._gatewayToken = ((IEnumerable<string>) result.Response.Response.Headers["gatewayToken"]).First<string>();
        if (result.Response.Response.Status == 510)
        {
          return context.Request.Path.Value == "/dotnetcoretest/login/login.fcc" ? 1 : 0;
        }

        string str1 = string.Format("\n\n{{Out: {0} - {1}", (object) result.Response.Response.Status.ToString(), string.IsNullOrEmpty(result.Response.Response.Body) ? (object) "empty body\n" : (object) result.Response.Response.Body);
        if (result.Response.Response.Headers != null)
        {
          string str2 = "Headers:\n" + string.Join("\n", result.Response.Response.Headers.Select<KeyValuePair<string, string[]>, string>((Func<KeyValuePair<string, string[]>, string>) (x => x.Key + ",{" + string.Join(",", x.Value) + "}")));
          str1 = str1 + "\n" + str2;
        }
        if (result.Response.Response.Cookies != null)
        {
          string str2 = "Cookies:\n" + string.Join("\n", result.Response.Response.Cookies.Select<JavaCookie, string>((Func<JavaCookie, string>) (x => x.Name + ",{" + string.Join(",", x.Value) + "}")));
          str1 = str1 + "\n" + str2;
        }
        if (context.Request.Headers != null && !((IDictionary<string, StringValues>) context.Request.Headers).ContainsKey("RequestVerificationToken"))
        {
          AntiforgeryTokenSet tokens = SSORestFilterHttpModuleExtensions._antiforgery.GetTokens(context);
          ((IDictionary<string, StringValues>) context.Request.Headers).Add(tokens.HeaderName, tokens.RequestToken);
        }
        if (context.Request.Headers != null)
        {
          string str2 = "Request.Headers:\n" + string.Join("\n", ((IEnumerable<KeyValuePair<string, StringValues>>) context.Request.Headers).Select<KeyValuePair<string, StringValues>, string>((Func<KeyValuePair<string, StringValues>, string>) (x => x.Key + ",{" + string.Join(",", x.Value) + "}")));
          str1 = str1 + "\n" + str2;
        }
        string str3 = str1 + "}}";
        if (result.Response.Response.Status == 100)
        {
          if (result.Response.Request.Headers != null)
          {
            Utils.FillHeadersForContextWithReflections(result.Response.Request.Headers, context.Request);
            if (this.ConfigParam.InjectAllHttp)
              Utils.FillHeadersForServerVariables(result.Response.Request.Headers, context.Request);
          }
          if (result.Response.Request.Cookies != null)
          {
            HttpRequest request = context.Request;
            List<JavaCookie> cookies1 = result.Response.Request.Cookies;
            IRequestCookieCollection cookies2 = context.Request.Cookies;
            HostString host1 = context.Request.Host;
            string host2 = host1.Host;
            RequestCookieCollection cookieCollection = (RequestCookieCollection) Utils.FillCookiesForContext((IEnumerable<JavaCookie>) cookies1, (object) cookies2, host2);
            request.Cookies = (IRequestCookieCollection) cookieCollection;
          }
          if (result.Response.Response.Cookies != null)
          {
            HttpRequest request = context.Request;
            List<JavaCookie> cookies1 = result.Response.Response.Cookies;
            IRequestCookieCollection cookies2 = context.Request.Cookies;
            HostString host1 = context.Request.Host;
            string host2 = host1.Host;
            RequestCookieCollection cookieCollection = (RequestCookieCollection) Utils.FillCookiesForContext((IEnumerable<JavaCookie>) cookies1, (object) cookies2, host2);
            request.Cookies= ((IRequestCookieCollection) cookieCollection);
            context.Items.Add((object) "idf_100cookies", (object) result.Response.Response.Cookies);
            Utils.FillCookieHeader(context.Request);
          }
          this._is510Request = false;
          return result.StatusCode;
        }
        if (result.Response.Response.Status == 510)
        {
          string str2 = this._gatewayHandshakeProcessor.DecoderResponse(context, result.Response);
          if (!string.IsNullOrEmpty(result.Response.Response.Body) && (result.Response.Response.Body.Contains("Signature Needed") || str2.Contains("Signature Needed")))
          {
            if (!this.ConfigParam.Handshake3xEnable)
              this._gatewayHandshakeProcessor.Handshake(context);
            else
              this._gatewayHandshakeProcessor.Handshake3(context, result.Response);
          }
          else
          {
            this.LogProvider.LogWrite("Gateway response stated content required, looking for local content to supply", LogSeverity.Debug);
            IFileInfo fileInfo =  SSORestFilterHttpModuleExtensions._environment.WebRootFileProvider.GetFileInfo(context.Request.Path);
            if (fileInfo != null && !fileInfo.Exists)
              fileInfo = SSORestFilterHttpModuleExtensions._environment.ContentRootFileProvider.GetFileInfo(context.Request.Path);
            if (fileInfo != null && fileInfo.Exists)
            {
              long unixTime = Utils.ConvertToUnixTime(new FileInfo(fileInfo.PhysicalPath).LastWriteTime);
              string str4 = System.IO.File.ReadAllText(fileInfo.PhysicalPath);
              //TODO
              //if (context.Request.Cookies.ContainsKey(".AspNetCore.Antiforgery.4wIg6XQlHu8"))
              //  context.Request.Cookies[".AspNetCore.Antiforgery.4wIg6XQlHu8"];
              AntiforgeryTokenSet tokens = SSORestFilterHttpModuleExtensions._antiforgery.GetTokens(context);
              string base64String = Convert.ToBase64String(Encoding.UTF8.GetBytes(str4.Replace("$$__RequestVerificationToken$$", tokens.RequestToken)));
              SessionExtensions.SetString(context.Session, "fcc_file_login", base64String);
              SessionExtensions.SetInt32(context.Session, "fcc_file_login_timestamp", (int) unixTime);
              AttributesManager.SetAttribute(context, "content", base64String);
              AttributesManager.SetAttribute(context, "contentTimestamp", Utils.UnixTimeNow().ToString((IFormatProvider) CultureInfo.InvariantCulture));
            }
          }
          this._is510Request = true;
          return this.GatewayProcessing(context);
        }
        context.Response.StatusCode = result.Response.Response.Status;
        if (result.Response.Response.Headers != null)
          Utils.FillHeadersForResponseContext(result.Response.Response.Headers, context.Response);
        HostString host3;
        if (result.Response.Response.Cookies != null)
        {
          List<JavaCookie> cookies = result.Response.Response.Cookies;
          HttpResponse response = context.Response;
          host3 = context.Request.Host;
          string host1 = host3.Host;
          Utils.FillCookiesForResponseContext((IEnumerable<JavaCookie>) cookies, response, host1);
        }
        if (!string.IsNullOrEmpty(result.Response.Response.Body))
        {
          byte[] buffer;
          try
          {
            buffer = Convert.FromBase64String(result.Response.Response.Body);
          }
          catch
          {
            buffer = Encoding.UTF8.GetBytes(result.Response.Response.Body);
          }
          context.Response.Body.Write(buffer, 0, buffer.Length);
        }
        else if (context.Request.Method == "POST" && context.Request.Path == "/dotnetcoretest/login/login.fcc" && (result.Response.Response.Headers != null && result.Response.Response.Headers.ContainsKey("Location")))
        {
          if (!context.Request.Cookies.ContainsKey(".AspNetCore.Antiforgery.4wIg6XQlHu8"))
            ;
        }
        else if (context.Request.Method == "GET" && context.Request.Path ==  "/dotnetcoretest/protected/protected-fcc" && (result.Response.Response.Headers != null && result.Response.Response.Headers.ContainsKey("Location")) && ((IDictionary<string, StringValues>) context.Request.Headers).ContainsKey("Referer"))
        {
          HttpRequest request = context.Request;
          UriBuilder uriBuilder1 = new UriBuilder();
          host3 = request.Host;
          uriBuilder1.Host = host3.Host;
          uriBuilder1.Scheme = request.Scheme;
          UriBuilder uriBuilder2 = uriBuilder1;
          host3 = request.Host;
          int? port = host3.Port;
          if (port.HasValue)
          {
            UriBuilder uriBuilder3 = uriBuilder2;
            host3 = request.Host;
            port = host3.Port;
            int num = port.Value;
            uriBuilder3.Port = num;
          }
          string str2 = uriBuilder2.ToString();
          if (str2.EndsWith("/"))
            str2 = str2.Substring(0, str2.Length - 1);
          string str4 = str2 + result.Response.Response.Headers["Location"][0];
          //((IEnumerable<string>) (object) context.Request.Headers["Referer"].FirstOrDefault<string>();
        }
        context.Response.Body.Flush();
        this._is510Request = false;
        return result.StatusCode;
      }
      this._is510Request = false;
      this.LogProvider.LogWrite("There are not available urls", LogSeverity.Error);
      this.LogProvider.LogWrite("There are not available urls", LogSeverity.Info);
      throw new Exception("There are not available urls");
    }

    private async Task<GatewayResponseMessage> RetryAsync(
      Func<HttpContext, string, GatewayResponseMessage> FuncGetResponseFromGateway,
      HttpContext context,
      int maxRetries,
      int retriesDelay,
      bool isGatewayRequest)
    {
      SSORestIISModule.ExchangeMessage.Processor.ResponseProcessor.ResponseProcessor responseProcessor = this;
      string str = await responseProcessor._gatewayConnectionPool.GetCurrentRequestUrlAsync(false, isGatewayRequest).ConfigureAwait(false);
      string prevUrl = string.Empty;
      while (!string.IsNullOrEmpty(str) && !str.Equals(prevUrl, StringComparison.OrdinalIgnoreCase))
      {
        while (Interlocked.CompareExchange(ref maxRetries, 0, 0) >= 0)
        {
          GatewayResponseMessage gatewayResponseMessage = FuncGetResponseFromGateway(context, str);
          if (gatewayResponseMessage != null)
            return gatewayResponseMessage;
          responseProcessor.LogProvider.LogWrite(string.Format("There are still attempts {0} to get successful response from gateway", (object) maxRetries), LogSeverity.Info);
          Interlocked.Decrement(ref maxRetries);
          Thread.Sleep(retriesDelay);
        }
        Interlocked.Exchange(ref maxRetries, responseProcessor.ConfigParam.MaxRetries);
        prevUrl = str;
        str = await responseProcessor._gatewayConnectionPool.GetCurrentRequestUrlAsync(true, false).ConfigureAwait(false);
        if (string.IsNullOrEmpty(str))
        {
          responseProcessor.LogProvider.LogWrite("There are not available urls. Failover Max retry reached. Exiting...", LogSeverity.Debug);
          throw new Exception("There are not available urls. Failover Max retry reached. Exiting...");
        }
        responseProcessor.LogProvider.LogWrite(string.Format("Use next url {0}", (object) str), LogSeverity.Info);
      }
      return (GatewayResponseMessage) null;
    }

    private GatewayResponseMessage GetResponseFromGateway(
      HttpContext context,
      string url)
    {
      MediaTypeHeaderValue mediaTypeHeaderValue = new MediaTypeHeaderValue("application/x-www-form-urlencoded");
      mediaTypeHeaderValue.Encoding = Encoding.UTF8;
      context.Request.ContentType = mediaTypeHeaderValue.ToString();
      this.LogProvider.LogWrite(string.Format("Processing request {0} {1}", (object) context.Request.Method, (object) UriHelper.GetDisplayUrl(context.Request)), LogSeverity.Info);
      string str = url + "/service/public/";
      if (UriHelper.GetDisplayUrl(context.Request).StartsWith(str, StringComparison.OrdinalIgnoreCase))
      {
        this.LogProvider.LogWrite("HandleSsoRestPublicEndpoints not implemented", LogSeverity.Error);
        throw new NotImplementedException();
      }
      try
      {
        using (WebResponse response = this._gatewayRequestFactory.CreateRequestToGateway(context, url).GetResponse())
        {
          HttpWebResponse httpWebResponse = (HttpWebResponse) response;
          int statusCode = (int) httpWebResponse.StatusCode;
          this.LogProvider.LogWrite(string.Format("Received {0} status code from gateway", (object) httpWebResponse.StatusCode), LogSeverity.Info);
          if (httpWebResponse.StatusCode == HttpStatusCode.NotFound || httpWebResponse.StatusCode == HttpStatusCode.BadGateway || (httpWebResponse.StatusCode == HttpStatusCode.ServiceUnavailable || httpWebResponse.StatusCode == HttpStatusCode.InternalServerError))
          {
            this.LogProvider.LogWrite(string.Format("Gateway URL not available {0}", (object) url), LogSeverity.Info);
            return (GatewayResponseMessage) null;
          }
          using (Stream responseStream = httpWebResponse.GetResponseStream())
          {
            if (responseStream == null)
              return (GatewayResponseMessage) null;
            using (MemoryStream memoryStream = new MemoryStream())
            {
              responseStream.CopyTo((Stream) memoryStream);
              memoryStream.Seek(0L, SeekOrigin.Begin);
              using (StreamReader streamReader = new StreamReader((Stream) memoryStream))
              {
                string end = streamReader.ReadToEnd();
                streamReader.Close();
                responseStream.Close();
                response.Close();
                GatewayResponse gatewayResponse = (GatewayResponse) JsonConvert.DeserializeObject<GatewayResponse>(end);
                this.LogProvider.LogWrite("Response details" + Environment.NewLine + JsonConvert.SerializeObject((object) gatewayResponse, (Formatting) 1), LogSeverity.Debug);
                return new GatewayResponseMessage()
                {
                  Response = gatewayResponse,
                  StatusCode = statusCode
                };
              }
            }
          }
        }
      }
      catch (ArgumentException ex)
      {
        throw ex;
      }
      catch (WebException ex)
      {
        this.LogProvider.LogWrite((Exception) ex, LogSeverity.Debug);
        this.LogProvider.LogWrite(string.Format("Gateway URL not available {0}", (object) url), LogSeverity.Info);
        return (GatewayResponseMessage) null;
      }
      catch (Exception ex)
      {
        this.LogProvider.LogWrite(ex, LogSeverity.Debug);
        this.LogProvider.LogWrite(string.Format("Gateway URL not available {0}", (object) url), LogSeverity.Info);
        return (GatewayResponseMessage) null;
      }
    }
  }
}
