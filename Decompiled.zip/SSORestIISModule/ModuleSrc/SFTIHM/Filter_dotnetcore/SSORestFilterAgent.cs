﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using SSORestIISModule.Core.Common.Http;

namespace SFTIHM.Filter_dotnetcore
{
  public class SSORestFilterAgent : SSORestFilterHttpModule
  {
    public SSORestFilterAgent(RequestDelegate next, IHostingEnvironment environment)
      : base(next, environment)
    {
    }
  }
}
