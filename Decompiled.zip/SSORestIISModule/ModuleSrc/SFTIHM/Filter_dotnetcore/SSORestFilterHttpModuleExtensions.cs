﻿using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;

namespace SFTIHM.Filter_dotnetcore
{
  public static class SSORestFilterHttpModuleExtensions
  {
    public static IHostingEnvironment _environment;
    public static IAntiforgery _antiforgery;

    public static IApplicationBuilder UseSSORestFilterHttpModuleExtensions(
      this IApplicationBuilder builder,
      IHostingEnvironment environment,
      IAntiforgery antiforgery)
    {
      SSORestFilterHttpModuleExtensions._environment = environment;
      SSORestFilterHttpModuleExtensions._antiforgery = antiforgery;
      return UseMiddlewareExtensions.UseMiddleware<SSORestFilterAgent>(builder, new object[1]
      {
        (object) environment
      });
    }
  }
}
