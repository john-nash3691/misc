﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Settings.SettingsManager
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using SFTIHM.Filter_dotnetcore;
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Threading.Tasks;
using System.Xml;

namespace SSORestIISModule.Core.Settings
{
  internal class SettingsManager : IDisposable
  {
    private ConcurrentDictionary<string, string> _settings;
    private readonly string _appConfigPath;
    private readonly string _globalConfigPath;
    private readonly string _siteName;
    private bool _disposed;
    private bool _isInit;

    public SettingsManager()
    {
      this._settings = new ConcurrentDictionary<string, string>();
      this._siteName = SSORestFilterHttpModuleExtensions._environment.ApplicationName;
      this._appConfigPath = Path.Combine(SSORestFilterHttpModuleExtensions._environment.WebRootPath ?? SSORestFilterHttpModuleExtensions._environment.ContentRootPath, "SSORestIISModule.app.config");
      this._globalConfigPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32\\inetsrv\\config\\SSORestIISModule.global.config");
    }

    public void Dispose()
    {
      this.Dispose(true);
      GC.SuppressFinalize((object) this);
    }

    protected virtual void Dispose(bool disposing)
    {
      if (this._disposed)
        return;
      if (disposing && this._settings != null)
      {
        this._settings.Clear();
        this._settings = (ConcurrentDictionary<string, string>) null;
      }
      this._disposed = true;
    }

    ~SettingsManager()
    {
      this.Dispose(false);
    }

    public async Task Init()
    {
      if (this._isInit)
        return;
      if (File.Exists(this._appConfigPath))
        await this.InitAppDirConfigSettingsAsync(this._appConfigPath);
      else
        await this.InitGlobalDirConfigSettingsAsync(this._globalConfigPath, this._siteName);
      this._isInit = true;
    }

    public string GetParameterValue(string parameterName, string defaultValue = null)
    {
      string str;
      if (!this._settings.TryGetValue(parameterName, out str))
        return defaultValue;
      return str.ToString();
    }

    public T GetParameterValue<T>(string parameterName, T defaultValue)
    {
      string str;
      if (!this._settings.TryGetValue(parameterName, out str))
        return defaultValue;
      return (T) Convert.ChangeType((object) str, typeof (T));
    }

    public bool ParameterExists(string parameterName)
    {
      string str;
      return this._settings.TryGetValue(parameterName, out str);
    }

    private void FillSettings(XmlNode settingsNode)
    {
      foreach (XmlNode childNode in settingsNode.ChildNodes)
      {
        string str;
        if (childNode.Name.Equals("add", StringComparison.InvariantCultureIgnoreCase) && childNode.Attributes != null && !this._settings.TryGetValue(childNode.Attributes["key"].Value, out str))
          this._settings.TryAdd(childNode.Attributes["key"].Value, childNode.Attributes["value"].Value);
      }
    }

    private XmlNode FindSettingsNode(XmlNodeList list, string name)
    {
      foreach (XmlNode xmlNode1 in list)
      {
        if (xmlNode1.Name.Equals("site", StringComparison.OrdinalIgnoreCase) && xmlNode1.HasChildNodes && (xmlNode1.Attributes?[nameof (name)] != null && xmlNode1.Attributes[nameof (name)].Value.Equals(name, StringComparison.OrdinalIgnoreCase)))
        {
          foreach (XmlNode xmlNode2 in xmlNode1)
          {
            if (xmlNode2.Name.Equals("settings", StringComparison.OrdinalIgnoreCase))
              return xmlNode2;
          }
        }
      }
      return (XmlNode) null;
    }

    private async Task InitAppDirConfigSettingsAsync(string settingsFilePath)
    {
      XmlDocument doc = new XmlDocument()
      {
        XmlResolver = (XmlResolver) null
      };
      using (StreamReader reader = new StreamReader((Stream) new FileStream(settingsFilePath, FileMode.Open, FileAccess.Read, FileShare.Read)))
      {
        string endAsync = await reader.ReadToEndAsync();
        reader.Close();
        doc.LoadXml(endAsync);
        foreach (XmlNode childNode in doc.ChildNodes)
        {
          if (childNode.Name.Equals("settings", StringComparison.OrdinalIgnoreCase))
            this.FillSettings(childNode);
        }
      }
    }

    private async Task InitGlobalDirConfigSettingsAsync(
      string settingsFilePath,
      string siteName)
    {
      if (!File.Exists(settingsFilePath))
        throw new ApplicationException("No global SSORestIISModule.config was found");
      using (StreamReader reader = new StreamReader((Stream) new FileStream(settingsFilePath, FileMode.Open, FileAccess.Read, FileShare.Read)))
      {
        XmlDocument doc = new XmlDocument()
        {
          XmlResolver = (XmlResolver) null
        };
        string endAsync = await reader.ReadToEndAsync();
        reader.Close();
        doc.LoadXml(endAsync);
        if (doc.DocumentElement == null)
          throw new ApplicationException("No default or site settings section was found in global SSORestIISModule.config");
        XmlNode settingsNode1 = this.FindSettingsNode(doc.DocumentElement.ChildNodes, "default_module_config");
        XmlNode settingsNode2 = this.FindSettingsNode(doc.DocumentElement.ChildNodes, siteName);
        if (settingsNode2 == null && settingsNode1 == null)
          throw new ApplicationException("No default or site settings section was found in global SSORestIISModule.config");
        this.FillSettings(settingsNode2 ?? settingsNode1);
        doc = (XmlDocument) null;
      }
    }
  }
}
