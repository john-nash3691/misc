﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Settings.SettingsProvider
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using System.Threading;
using System.Threading.Tasks;

namespace SSORestIISModule.Core.Settings
{
  internal class SettingsProvider
  {
    private readonly SettingsManager settingsManager = new SettingsManager();
    private static SettingsProvider instance;

    private SettingsProvider()
    {
    }

    public static SettingsProvider GetProvider()
    {
      if (SettingsProvider.instance != null)
        return SettingsProvider.instance;
      SettingsProvider settingsProvider = new SettingsProvider();
      Interlocked.CompareExchange<SettingsProvider>(ref SettingsProvider.instance, settingsProvider, (SettingsProvider) null);
      return SettingsProvider.instance;
    }

    public async Task<string> GetParameterValueAsync(string parameterName, string defaultValue = null)
    {
      if (SettingsProvider.instance == null)
        return (string) null;
      await SettingsProvider.instance.settingsManager.Init();
      return SettingsProvider.instance.settingsManager.GetParameterValue(parameterName, defaultValue);
    }

    public async Task<T> GetParameterValueAsync<T>(string parameterName, T defaultValue)
    {
      if (SettingsProvider.instance == null)
        return default (T);
      await SettingsProvider.instance.settingsManager.Init();
      return SettingsProvider.instance.settingsManager.GetParameterValue<T>(parameterName, defaultValue);
    }

    public async Task<bool> ParameterExistsAsync(string parameterName)
    {
      if (SettingsProvider.instance == null)
        return false;
      await SettingsProvider.instance.settingsManager.Init();
      return SettingsProvider.instance.settingsManager.ParameterExists(parameterName);
    }
  }
}
