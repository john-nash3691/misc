﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Configuration.ConfigurationProvider
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using SSORestIISModule.Core.Settings;
using System.Threading;
using System.Threading.Tasks;

namespace SSORestIISModule.Core.Configuration
{
  internal class ConfigurationProvider
  {
    private static ConfigurationProvider _instance;
    private static ConfigurationModuleParameters _configParameters;

    private ConfigurationProvider()
    {
    }

    public static ConfigurationProvider GetProvider()
    {
      if (ConfigurationProvider._instance != null)
        return ConfigurationProvider._instance;
      ConfigurationProvider configurationProvider = new ConfigurationProvider();
      Interlocked.CompareExchange<ConfigurationProvider>(ref ConfigurationProvider._instance, configurationProvider, (ConfigurationProvider) null);
      return ConfigurationProvider._instance;
    }

    public async Task<ConfigurationModuleParameters> GetConfigurationModuleParametersAsync()
    {
      if (ConfigurationProvider._instance == null)
        return (ConfigurationModuleParameters) null;
      if (ConfigurationProvider._configParameters != null)
        return ConfigurationProvider._configParameters;
      ConfigurationModuleParameters moduleParameters1 = new ConfigurationModuleParameters();
      ConfigurationModuleParameters moduleParameters2 = moduleParameters1;
      moduleParameters2.MaxConnections = await SettingsProvider.GetProvider().GetParameterValueAsync<int>("maxConnections", 200);
      ConfigurationModuleParameters moduleParameters3 = moduleParameters1;
      moduleParameters3.ConnectionTimeout = await SettingsProvider.GetProvider().GetParameterValueAsync<int>("connectionTimeout", 10000);
      ConfigurationModuleParameters moduleParameters4 = moduleParameters1;
      moduleParameters4.Expect100Continue = await SettingsProvider.GetProvider().GetParameterValueAsync<bool>("expect100Continue", true);
      ConfigurationModuleParameters moduleParameters5 = moduleParameters1;
      moduleParameters5.MaxRetries = await SettingsProvider.GetProvider().GetParameterValueAsync<int>("maxRetries", 5);
      ConfigurationModuleParameters moduleParameters6 = moduleParameters1;
      moduleParameters6.RetriesDelay = await SettingsProvider.GetProvider().GetParameterValueAsync<int>("retriesDelay", 100);
      ConfigurationModuleParameters moduleParameters7 = moduleParameters1;
      moduleParameters7.SendFormParameters = await SettingsProvider.GetProvider().GetParameterValueAsync<bool>("sendFormParameters", false);
      ConfigurationModuleParameters moduleParameters8 = moduleParameters1;
      moduleParameters8.DisableVersionHeaders = await SettingsProvider.GetProvider().GetParameterValueAsync<bool>("disableVersionHeaders", false);
      ConfigurationModuleParameters moduleParameters9 = moduleParameters1;
      moduleParameters9.SSOZone = await SettingsProvider.GetProvider().GetParameterValueAsync("ssoZone", "SM");
      ConfigurationModuleParameters moduleParameters10 = moduleParameters1;
      moduleParameters10.SendRequestHeaders = await SettingsProvider.GetProvider().GetParameterValueAsync("sendRequestHeaders", string.Empty);
      ConfigurationModuleParameters moduleParameters11 = moduleParameters1;
      moduleParameters11.IgnoreRequestHeaders = await SettingsProvider.GetProvider().GetParameterValueAsync("ignoreRequestHeaders", string.Empty);
      ConfigurationModuleParameters moduleParameters12 = moduleParameters1;
      moduleParameters12.GatewayFailoverEnable = await SettingsProvider.GetProvider().GetParameterValueAsync<bool>("gatewayFailoverEnable", false);
      ConfigurationModuleParameters moduleParameters13 = moduleParameters1;
      moduleParameters13.DisableGatewayCertCheck = await SettingsProvider.GetProvider().GetParameterValueAsync<bool>("disableGatewayCertCheck", false);
      ConfigurationModuleParameters moduleParameters14 = moduleParameters1;
      moduleParameters14.IntervalCheckUrl = await SettingsProvider.GetProvider().GetParameterValueAsync<int>("intervalCheckUrl", 1000);
      ConfigurationModuleParameters moduleParameters15 = moduleParameters1;
      moduleParameters15.TransactionTimeWarningThreshold = (long) await SettingsProvider.GetProvider().GetParameterValueAsync<int>("transactionTimeWarningThreshold", 0);
      ConfigurationModuleParameters moduleParameters16 = moduleParameters1;
      moduleParameters16.Enabled = await SettingsProvider.GetProvider().GetParameterValueAsync<bool>("enabled", true);
      ConfigurationModuleParameters moduleParameters17 = moduleParameters1;
      moduleParameters17.ProxyHost = await SettingsProvider.GetProvider().GetParameterValueAsync("proxyhost", string.Empty);
      ConfigurationModuleParameters moduleParameters18 = moduleParameters1;
      moduleParameters18.ProxyPort = await SettingsProvider.GetProvider().GetParameterValueAsync<int>("proxyport", 8080);
      ConfigurationModuleParameters moduleParameters19 = moduleParameters1;
      moduleParameters19.ProxyScheme = await SettingsProvider.GetProvider().GetParameterValueAsync("proxyscheme", "http");
      ConfigurationModuleParameters moduleParameters20 = moduleParameters1;
      moduleParameters20.ProxyEnable = await SettingsProvider.GetProvider().GetParameterValueAsync<bool>("proxyenable", false);
      ConfigurationModuleParameters moduleParameters21 = moduleParameters1;
      moduleParameters21.SsorestAcoName = await SettingsProvider.GetProvider().GetParameterValueAsync("acoName", (string) null);
      ConfigurationModuleParameters moduleParameters22 = moduleParameters1;
      moduleParameters22.PluginIdName = await SettingsProvider.GetProvider().GetParameterValueAsync("pluginID", (string) null);
      ConfigurationModuleParameters moduleParameters23 = moduleParameters1;
      moduleParameters23.SecretKeyName = await SettingsProvider.GetProvider().GetParameterValueAsync("secretKey", (string) null);
      ConfigurationModuleParameters moduleParameters24 = moduleParameters1;
      moduleParameters24.IgnoreExtName = await SettingsProvider.GetProvider().GetParameterValueAsync("ignoreExt", (string) null);
      ConfigurationModuleParameters moduleParameters25 = moduleParameters1;
      moduleParameters25.IgnoreUrlName = await SettingsProvider.GetProvider().GetParameterValueAsync("ignoreUrl", (string) null);
      ConfigurationModuleParameters moduleParameters26 = moduleParameters1;
      moduleParameters26.IgnoreHostName = await SettingsProvider.GetProvider().GetParameterValueAsync("ignoreHost", (string) null);
      ConfigurationModuleParameters moduleParameters27 = moduleParameters1;
      moduleParameters27.GatewayUrls = await SettingsProvider.GetProvider().GetParameterValueAsync("gatewayurl", (string) null);
      ConfigurationModuleParameters moduleParameters28 = moduleParameters1;
      moduleParameters28.TrustStore = await SettingsProvider.GetProvider().GetParameterValueAsync("truststore", (string) null);
      ConfigurationModuleParameters moduleParameters29 = moduleParameters1;
      moduleParameters29.TrustStorePass = await SettingsProvider.GetProvider().GetParameterValueAsync("truststorepass", "changeit");
      ConfigurationModuleParameters moduleParameters30 = moduleParameters1;
      moduleParameters30.InjectAllHttp = await SettingsProvider.GetProvider().GetParameterValueAsync<bool>("injectAllHttp", false);
      ConfigurationModuleParameters moduleParameters31 = moduleParameters1;
      moduleParameters31.ConnectionPoolEnable = await SettingsProvider.GetProvider().GetParameterValueAsync<bool>("connectionPoolEnable", false);
      ConfigurationModuleParameters moduleParameters32 = moduleParameters1;
      moduleParameters32.Handshake3xEnable = await SettingsProvider.GetProvider().GetParameterValueAsync<bool>("handshake3xEnable", false);
      ConfigurationModuleParameters moduleParameters33 = moduleParameters1;
      moduleParameters33.NormalInterval = (long) await SettingsProvider.GetProvider().GetParameterValueAsync<int>("normalInterval", 300000);
      ConfigurationModuleParameters moduleParameters34 = moduleParameters1;
      moduleParameters34.UrgentInterval = (long) await SettingsProvider.GetProvider().GetParameterValueAsync<int>("urgentInterval", 60000);
      ConfigurationModuleParameters moduleParameters35 = moduleParameters1;
      moduleParameters35.Qourum = await SettingsProvider.GetProvider().GetParameterValueAsync<int>("qourum", 50);
      ConfigurationModuleParameters moduleParameters36 = moduleParameters1;
      moduleParameters36.SecurityProtocol = await SettingsProvider.GetProvider().GetParameterValueAsync("securityProtocol", "TLS12");
      ConfigurationProvider._configParameters = moduleParameters1;
      moduleParameters2 = (ConfigurationModuleParameters) null;
      moduleParameters3 = (ConfigurationModuleParameters) null;
      moduleParameters4 = (ConfigurationModuleParameters) null;
      moduleParameters5 = (ConfigurationModuleParameters) null;
      moduleParameters6 = (ConfigurationModuleParameters) null;
      moduleParameters7 = (ConfigurationModuleParameters) null;
      moduleParameters8 = (ConfigurationModuleParameters) null;
      moduleParameters9 = (ConfigurationModuleParameters) null;
      moduleParameters10 = (ConfigurationModuleParameters) null;
      moduleParameters11 = (ConfigurationModuleParameters) null;
      moduleParameters12 = (ConfigurationModuleParameters) null;
      moduleParameters13 = (ConfigurationModuleParameters) null;
      moduleParameters14 = (ConfigurationModuleParameters) null;
      moduleParameters15 = (ConfigurationModuleParameters) null;
      moduleParameters16 = (ConfigurationModuleParameters) null;
      moduleParameters17 = (ConfigurationModuleParameters) null;
      moduleParameters18 = (ConfigurationModuleParameters) null;
      moduleParameters19 = (ConfigurationModuleParameters) null;
      moduleParameters20 = (ConfigurationModuleParameters) null;
      moduleParameters21 = (ConfigurationModuleParameters) null;
      moduleParameters22 = (ConfigurationModuleParameters) null;
      moduleParameters23 = (ConfigurationModuleParameters) null;
      moduleParameters24 = (ConfigurationModuleParameters) null;
      moduleParameters25 = (ConfigurationModuleParameters) null;
      moduleParameters26 = (ConfigurationModuleParameters) null;
      moduleParameters27 = (ConfigurationModuleParameters) null;
      moduleParameters28 = (ConfigurationModuleParameters) null;
      moduleParameters29 = (ConfigurationModuleParameters) null;
      moduleParameters30 = (ConfigurationModuleParameters) null;
      moduleParameters31 = (ConfigurationModuleParameters) null;
      moduleParameters32 = (ConfigurationModuleParameters) null;
      moduleParameters33 = (ConfigurationModuleParameters) null;
      moduleParameters34 = (ConfigurationModuleParameters) null;
      moduleParameters35 = (ConfigurationModuleParameters) null;
      moduleParameters36 = (ConfigurationModuleParameters) null;
      moduleParameters1 = (ConfigurationModuleParameters) null;
      return ConfigurationProvider._configParameters;
    }
  }
}
