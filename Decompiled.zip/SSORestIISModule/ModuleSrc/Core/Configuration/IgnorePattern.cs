﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Configuration.IgnorePattern
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SSORestIISModule.Core.Configuration
{
  internal class IgnorePattern : IDisposable
  {
    private bool disposed;

    private IDictionary<string, string> IgnoreExts { get; set; }

    private IDictionary<string, string> IgnoreUrls { get; set; }

    private IDictionary<string, string> IgnoreHosts { get; set; }

    public IgnorePattern(string ignoreExt, string ignoreUrl, string ignoreHost)
    {
      this.IgnoreExts = this.PrepareValues(ignoreExt);
      this.IgnoreUrls = this.PrepareValues(ignoreUrl);
      this.IgnoreHosts = this.PrepareValues(ignoreHost);
    }

    private IDictionary<string, string> PrepareValues(string initialStr)
    {
      if (string.IsNullOrEmpty(initialStr))
        return (IDictionary<string, string>) null;
      return (IDictionary<string, string>) ((IEnumerable<string>) initialStr.Split(',', StringSplitOptions.None)).Select<string, string>((Func<string, string>) (item => item.ToLowerInvariant())).ToDictionary<string, string, string>((Func<string, string>) (key => key), (Func<string, string>) (s => s));
    }

    public bool CheckIfIgnored(Uri uri)
    {
      int num = 0;
      if (this.IgnoreExts != null && this.IgnoreExts.Any<KeyValuePair<string, string>>() && this.IgnoreExts.Keys.Contains<string>(Path.GetExtension(uri.AbsolutePath), (IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase))
        ++num;
      if (this.IgnoreHosts != null && this.IgnoreHosts.Any<KeyValuePair<string, string>>() && this.IgnoreHosts.Keys.Contains<string>(uri.Host, (IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase))
        ++num;
      if (this.IgnoreUrls != null && this.IgnoreUrls.Any<KeyValuePair<string, string>>() && this.IgnoreUrls.Keys.Contains<string>(uri.AbsolutePath, (IEqualityComparer<string>) StringComparer.OrdinalIgnoreCase))
        ++num;
      return num > 0;
    }

    public void Dispose()
    {
      this.Dispose(true);
      GC.SuppressFinalize((object) this);
    }

    protected virtual void Dispose(bool disposing)
    {
      if (this.disposed)
        return;
      if (disposing)
      {
        this.IgnoreExts?.Clear();
        this.IgnoreUrls?.Clear();
        this.IgnoreHosts?.Clear();
      }
      this.disposed = true;
    }

    ~IgnorePattern()
    {
      this.Dispose(false);
    }
  }
}
