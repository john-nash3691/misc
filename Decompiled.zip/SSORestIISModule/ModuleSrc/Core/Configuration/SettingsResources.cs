﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Configuration.SettingsResources
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

namespace SSORestIISModule.Core.Configuration
{
  internal class SettingsResources
  {
    internal class Key
    {
      public const string GatewayUrls = "gatewayurl";
      public const string Enabled = "enabled";
      public const string NormalInterval = "normalInterval";
      public const string UrgentInterval = "urgentInterval";
      public const string Qourum = "qourum";
      public const string SsorestGatewayServices = "gateway";
      public const string SsorestServices = "service";
      public const string SsorestPublicServices = "public";
      public const string SsorestAcoName = "acoName";
      public const string SecretKeyName = "secretKey";
      public const string PluginIdName = "pluginID";
      public const string ProxyHost = "proxyhost";
      public const string ProxyPort = "proxyport";
      public const string ProxyScheme = "proxyscheme";
      public const string ProxyEnable = "proxyenable";
      public const string TrustStore = "truststore";
      public const string TrustStorePass = "truststorepass";
      public const string InjectAllHttp = "injectAllHttp";
      public const string ConnectionPoolEnable = "connectionPoolEnable";
      public const string IgnoreExtName = "ignoreExt";
      public const string IgnoreUrlName = "ignoreUrl";
      public const string IgnoreHostName = "ignoreHost";
      public const string MaxConnections = "maxConnections";
      public const string ConnectionTimeout = "connectionTimeout";
      public const string Expect100Continue = "expect100Continue";
      public const string MaxRetries = "maxRetries";
      public const string RetriesDelay = "retriesDelay";
      public const string SendFormParameters = "sendFormParameters";
      public const string DisableVersionHeaders = "disableVersionHeaders";
      public const string SSOZone = "ssoZone";
      public const string SendRequestHeaders = "sendRequestHeaders";
      public const string IgnoreRequestHeaders = "ignoreRequestHeaders";
      public const string GatewayFailoverEnable = "gatewayFailoverEnable";
      public const string DisableGatewayCertCheck = "disableGatewayCertCheck";
      public const string IntervalCheckUrl = "intervalCheckUrl";
      public const string TransactionTimeWarningThreshold = "transactionTimeWarningThreshold";
      public const string Handshake3xEnable = "handshake3xEnable";
      public const string SecurityProtocol = "securityProtocol";
    }
  }
}
