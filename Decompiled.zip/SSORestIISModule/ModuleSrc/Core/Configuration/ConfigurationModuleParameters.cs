﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Configuration.ConfigurationModuleParameters
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

namespace SSORestIISModule.Core.Configuration
{
  public class ConfigurationModuleParameters
  {
    public int MaxConnections { get; set; }

    public int ConnectionTimeout { get; set; }

    public bool Expect100Continue { get; set; }

    public int MaxRetries { get; set; }

    public int RetriesDelay { get; set; }

    public bool SendFormParameters { get; set; }

    public bool DisableVersionHeaders { get; set; }

    public string SSOZone { get; set; }

    public string SendRequestHeaders { get; set; }

    public string IgnoreRequestHeaders { get; set; }

    public bool GatewayFailoverEnable { get; set; }

    public bool DisableGatewayCertCheck { get; set; }

    public int IntervalCheckUrl { get; set; }

    public long TransactionTimeWarningThreshold { get; set; }

    public bool Enabled { get; set; }

    public string ProxyHost { get; set; }

    public int ProxyPort { get; set; }

    public string ProxyScheme { get; set; }

    public bool ProxyEnable { get; set; }

    public string SsorestAcoName { get; set; }

    public string PluginIdName { get; set; }

    public string SecretKeyName { get; set; }

    public string IgnoreExtName { get; set; }

    public string IgnoreUrlName { get; set; }

    public string IgnoreHostName { get; set; }

    public string GatewayUrls { get; set; }

    public string TrustStore { get; set; }

    public string TrustStorePass { get; set; }

    public bool InjectAllHttp { get; set; }

    public bool ConnectionPoolEnable { get; set; }

    public bool Handshake3xEnable { get; set; }

    public long NormalInterval { get; set; }

    public long UrgentInterval { get; set; }

    public int Qourum { get; set; }

    public string SecurityProtocol { get; set; }
  }
}
