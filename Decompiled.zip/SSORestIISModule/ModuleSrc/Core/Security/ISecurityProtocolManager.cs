﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Security.ISecurityProtocolManager
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using System.Net;

namespace SSORestIISModule.Core.Security
{
  internal interface ISecurityProtocolManager
  {
    SecurityProtocolType GetCurrentSecurityProtocol();
  }
}
