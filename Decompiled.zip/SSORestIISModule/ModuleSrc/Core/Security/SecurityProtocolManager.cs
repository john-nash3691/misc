﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Security.SecurityProtocolManager
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using System.Net;

namespace SSORestIISModule.Core.Security
{
  internal class SecurityProtocolManager : ISecurityProtocolManager
  {
    private readonly string _securityProtocol;

    public SecurityProtocolManager()
    {
    }

    public SecurityProtocolManager(string securityProtocol)
    {
      this._securityProtocol = securityProtocol;
    }

    public SecurityProtocolType GetCurrentSecurityProtocol()
    {
      string upper = this._securityProtocol.ToUpper();
      if (upper == "TLS")
        return SecurityProtocolType.Tls;
      if (upper == "TLS11")
        return SecurityProtocolType.Tls11;
      if (upper == "TLS12")
        return SecurityProtocolType.Tls12;
      return upper == "SSL3" ? SecurityProtocolType.Ssl3 : SecurityProtocolType.SystemDefault;
    }
  }
}
