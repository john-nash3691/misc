﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Security.SecurityProvider
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using SSORestIISModule.Core.Common.Log.Enum;
using SSORestIISModule.Core.Common.Module;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace SSORestIISModule.Core.Security
{
  internal class SecurityProvider : AbstractModule, ISecurityProvider
  {
    private readonly bool _disableCheckCertificate;
    private readonly string _securityProtocol;
    private readonly ISecurityProtocolManager _securityProtocolManager;

    public SecurityProvider()
    {
    }

    public SecurityProvider(bool disableCheck, string securityProtocol)
    {
      this._disableCheckCertificate = disableCheck;
      this._securityProtocol = securityProtocol;
      this._securityProtocolManager = (ISecurityProtocolManager) new SecurityProtocolManager(securityProtocol);
    }

    public void ApplySecuritySettings()
    {
      ServicePointManager.SecurityProtocol = this._securityProtocolManager.GetCurrentSecurityProtocol();
      this.LogProvider.LogWrite(string.Format("Current using security protocol: {0}", (object) string.Join(",", (object) ServicePointManager.SecurityProtocol)), LogSeverity.Info);
      ServicePointManager.ServerCertificateValidationCallback = (RemoteCertificateValidationCallback) ((sender, certificate, chain, sslPolicyErrors) =>
      {
        if (this._disableCheckCertificate || sslPolicyErrors == SslPolicyErrors.None)
          return true;
        this.LogProvider.LogWrite(string.Format("Certificate has error {0}", (object) sslPolicyErrors), LogSeverity.Info);
        this.LogProvider.LogWrite(string.Format("Chain statuses: {0}", (object) string.Join(",", ((IEnumerable<X509ChainStatus>) chain.ChainStatus).Select<X509ChainStatus, string>((Func<X509ChainStatus, string>) (d => string.Format("Status {0}: {1}", (object) d.Status, (object) d.StatusInformation))))), LogSeverity.Info);
        return false;
      });
    }
  }
}
