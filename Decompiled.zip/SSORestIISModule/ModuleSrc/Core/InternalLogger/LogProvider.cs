﻿using NLog;
using SSORestIISModule.Core.Common.Log.Enum;
using System;
using Microsoft.Extensions.Logging;

namespace SSORestIISModule.Core.InternalLogger
{
  public class LogProvider : ILogProvider
  {
    private readonly Logger _logger = LogManager.GetCurrentClassLogger();

    public void LogWrite(string message, LogSeverity severity)
    {
      switch (severity)
      {
        case LogSeverity.Info:
          this._logger.Info(message);
          break;
        case LogSeverity.Trace:
          this._logger.Trace(message);
          break;
        case LogSeverity.Debug:
          this._logger.Debug(message);
          break;
        case LogSeverity.Warn:
          this._logger.Warn(message);
          break;
        case LogSeverity.Error:
          this._logger.Error(message);
          break;
      }
    }

    public void LogWrite(Exception ex, string message, LogSeverity severity)
    {
      switch (severity)
      {
        case LogSeverity.Info:
          this._logger.Info(ex, message);
          break;
        case LogSeverity.Trace:
          this._logger.Trace(ex, message);
          break;
        case LogSeverity.Debug:
          this._logger.Debug(ex, message);
          break;
        case LogSeverity.Warn:
          this._logger.Warn(ex, message);
          break;
        case LogSeverity.Error:
          this._logger.Error(ex, message);
          break;
      }
    }

    public void LogWrite(Exception ex, LogSeverity severity)
    {
      switch (severity)
      {
        case LogSeverity.Info:
          this._logger.Info<Exception>(ex);
          break;
        case LogSeverity.Trace:
          this._logger.Trace<Exception>(ex);
          break;
        case LogSeverity.Debug:
          this._logger.Debug<Exception>(ex);
          break;
        case LogSeverity.Warn:
          this._logger.Warn<Exception>(ex);
          break;
        case LogSeverity.Error:
          this._logger.Error<Exception>(ex);
          break;
      }
    }
  }
}
