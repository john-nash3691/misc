﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.ConnectionPool.SSOZonePoolManager
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using SSORestIISModule.Core.Common.Gateway;
using System;
using System.Collections.Generic;

namespace SSORestIISModule.Core.ConnectionPool
{
  public class SSOZonePoolManager
  {
    private readonly string[] _pool;

    private bool CheckContentsSSOZone(string value)
    {
      bool flag = false;
      if (this._pool != null && this._pool.Length != 0)
      {
        foreach (string str in this._pool)
        {
          if (value.StartsWith(str, StringComparison.OrdinalIgnoreCase))
          {
            flag = true;
            break;
          }
        }
      }
      else
        flag = true;
      return flag;
    }

    public SSOZonePoolManager(string[] ssoZonePool)
    {
      this._pool = ssoZonePool;
    }

    public List<JavaCookie> GetRequestCookies(IEnumerable<JavaCookie> cookies)
    {
      List<JavaCookie> javaCookieList = new List<JavaCookie>();
      foreach (JavaCookie cookie in cookies)
      {
        if (this.CheckContentsSSOZone(cookie.Name))
          javaCookieList.Add(cookie);
      }
      return javaCookieList;
    }
  }
}
