﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.ConnectionPool.RequestHeaderPoolManager
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace SSORestIISModule.Core.ConnectionPool
{
  public class RequestHeaderPoolManager
  {
    private readonly string[] _sendRequestHeadersPool;
    private readonly string[] _ignoreRequestHeadersPool;

    public RequestHeaderPoolManager(
      string[] sendRequestHeadersPool,
      string[] ignoreRequestHeadersPool)
    {
      this._sendRequestHeadersPool = sendRequestHeadersPool;
      this._ignoreRequestHeadersPool = ignoreRequestHeadersPool;
    }

    private bool CheckRequestHeaders(string value)
    {
      if (this._sendRequestHeadersPool != null && this._sendRequestHeadersPool.Length != 0)
        return ((IEnumerable<string>) this._sendRequestHeadersPool).Contains<string>(value.ToUpper());
      return true;
    }

    private bool CheckIgnoreRequestHeaders(string value)
    {
      if (this._ignoreRequestHeadersPool != null && this._ignoreRequestHeadersPool.Length != 0)
        return ((IEnumerable<string>) this._ignoreRequestHeadersPool).Contains<string>(value.ToUpper());
      return false;
    }

    public Dictionary<string, string[]> GetRequestHeaders(
      Dictionary<string, string[]> headers)
    {
      Dictionary<string, string[]> dictionary = new Dictionary<string, string[]>();
      foreach (KeyValuePair<string, string[]> header in headers)
      {
        if (this._sendRequestHeadersPool != null && this._sendRequestHeadersPool.Length != 0)
        {
          if (!this.CheckIgnoreRequestHeaders(header.Key))
          {
            string[] array = ((IEnumerable<string>) header.Value).Select<string, string>((Func<string, string>) (x => x = WebUtility.UrlDecode(x))).ToArray<string>();
            for (int index = 0; index < array.Length; ++index)
            {
              if (array[index].EndsWith("=="))
                array[index] = array[index].TrimEnd('=');
            }
            dictionary.Add(header.Key, array);
          }
        }
        else if (!this.CheckRequestHeaders(header.Key))
        {
          string[] array = ((IEnumerable<string>) header.Value).Select<string, string>((Func<string, string>) (x => x = WebUtility.UrlDecode(x))).ToArray<string>();
          dictionary.Add(header.Key, array);
        }
      }
      string key = "X-IDFC-SSO-VERSION";
      foreach (string str in this._sendRequestHeadersPool)
      {
        if (str.Contains(key))
        {
          string[] strArray = str.Split('=', StringSplitOptions.None);
          if (strArray.Length == 2)
          {
            dictionary.Add(key, new string[1]{ strArray[1] });
            break;
          }
          break;
        }
      }
      return dictionary;
    }
  }
}
