﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.ConnectionPool.GatewayConnectionPool
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using SSORestIISModule.Core.Common.Log.Enum;
using SSORestIISModule.Core.InternalLogger;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace SSORestIISModule.Core.ConnectionPool
{
  public class GatewayConnectionPool : IGatewayConnectionPool
  {
    private static object _taskLocker = new object();
    private ConcurrentQueue<string> _poolGatewayUrls;
    private TimeSpan _lastCheckTime;
    private volatile bool _isPoolRunning;
    private volatile bool _isConnectionPoolEnable;
    private volatile string _gatewayUrls;
    private readonly int _timeout;
    private readonly int _maxRetries;
    private readonly int _retriesDelay;
    private readonly bool _gatewayFailoverEnable;
    private readonly int _intervalCheckUrl;
    private readonly ILogProvider _logProvider;
    private readonly int _qourum;
    private readonly long _normalInterval;
    private readonly long _urgentInterval;
    private static bool _isInitialized;
    private static Task _infiniteTask;
    private static CancellationTokenSource _token;
    private static long _currentInterval;
    private static int _useAgeCounter;

    private static string CurrentUrl { get; set; }

    private static string FirstUrl { get; set; }

    public GatewayConnectionPool()
    {
    }

    public GatewayConnectionPool(
      ILogProvider logProvider,
      string configUrls,
      bool failoverEnable,
      int timeout,
      int maxRetries,
      int retriesDelay,
      int intervalCheckUrl,
      bool expect100Continue,
      int maxConnections,
      long normalInterval,
      long urgentInterval,
      int qourum,
      bool isConnectionPoolEnable)
    {
      this._gatewayUrls = configUrls;
      this._gatewayFailoverEnable = failoverEnable;
      this._isConnectionPoolEnable = isConnectionPoolEnable;
      this._timeout = timeout;
      this._maxRetries = maxRetries;
      this._retriesDelay = retriesDelay;
      this._intervalCheckUrl = intervalCheckUrl;
      this._logProvider = logProvider;
      this._normalInterval = normalInterval;
      this._urgentInterval = urgentInterval;
      this._qourum = qourum;
      this._poolGatewayUrls = new ConcurrentQueue<string>();
      ServicePointManager.Expect100Continue = expect100Continue;
      ServicePointManager.DefaultConnectionLimit = maxConnections;
      ServicePointManager.MaxServicePoints = maxConnections;
    }

    public async Task InitAsync()
    {
      await this.ParserConfigGatewayUrlsAsync(this._gatewayUrls).ConfigureAwait(false);
      if (this._poolGatewayUrls.Count == 0)
        throw new ArgumentException("No valid gatewayurls were found");
      if (!this._gatewayFailoverEnable)
      {
        Random rnd = new Random();
        this._poolGatewayUrls = new ConcurrentQueue<string>((IEnumerable<string>) this._poolGatewayUrls.OrderBy<string, int>((Func<string, int>) (x => rnd.Next())).ToArray<string>());
      }
      if (GatewayConnectionPool._isInitialized)
        return;
      GatewayConnectionPool.CurrentUrl = GatewayConnectionPool.FirstUrl;
      GatewayConnectionPool._isInitialized = true;
      if (!this._isConnectionPoolEnable)
        return;
      this.Start(false);
    }

    public void Stop()
    {
      if (!this._isPoolRunning)
        return;
      lock (GatewayConnectionPool._taskLocker)
      {
        if (GatewayConnectionPool._useAgeCounter - 1 <= 0)
        {
          this._logProvider.LogWrite("About to stop infinite thread", LogSeverity.Debug);
          using (GatewayConnectionPool._token)
            GatewayConnectionPool._token.Cancel();
          this._isPoolRunning = false;
        }
        else
        {
          --GatewayConnectionPool._useAgeCounter;
          this._logProvider.LogWrite(string.Format("Decrementing UsageCounter. New value is {0}", (object) GatewayConnectionPool._useAgeCounter), LogSeverity.Debug);
        }
      }
    }

    public async Task<string> GetCurrentRequestUrlAsync(bool next = false, bool is510Request = false)
    {
      if (this._poolGatewayUrls.IsEmpty)
        return (string) null;
      if (is510Request)
        return GatewayConnectionPool.CurrentUrl + "/service/gateway/evaluate";
      if (!next)
        return await this.FailoverProcessingAsync(GatewayConnectionPool.CurrentUrl).ConfigureAwait(false) + "/service/gateway/evaluate";
      string result;
      if (this._poolGatewayUrls.Count == 1)
      {
        this._poolGatewayUrls.TryPeek(out result);
        GatewayConnectionPool.CurrentUrl = result;
      }
      else
      {
        if (this._poolGatewayUrls.Count == 0)
        {
          if (this._isPoolRunning)
          {
            lock (GatewayConnectionPool._taskLocker)
              this._poolGatewayUrls = new ConcurrentQueue<string>((IEnumerable<string>) this._gatewayUrls.Split(',', StringSplitOptions.None));
          }
          else
            this._poolGatewayUrls = new ConcurrentQueue<string>((IEnumerable<string>) this._gatewayUrls.Split(',', StringSplitOptions.None));
        }
        this._poolGatewayUrls.TryDequeue(out result);
        GatewayConnectionPool.CurrentUrl = result;
      }
      return await this.FailoverProcessingAsync(result).ConfigureAwait(false) + "/service/gateway/evaluate";
    }

    private void Start(bool waitFirstTime = false)
    {
      if (!GatewayConnectionPool._isInitialized)
        return;
      lock (GatewayConnectionPool._taskLocker)
      {
        if (GatewayConnectionPool._infiniteTask == null)
        {
          GatewayConnectionPool._token = new CancellationTokenSource();
          this._logProvider.LogWrite("Starting infinite thread", LogSeverity.Debug);
          GatewayConnectionPool._infiniteTask = Task.Factory.StartNew((Action) (() =>
          {
            if (waitFirstTime)
              Thread.Sleep((int) GatewayConnectionPool._currentInterval);
            while (true)
            {
              try
              {
                GatewayConnectionPool._token.Token.ThrowIfCancellationRequested();
              }
              catch (OperationCanceledException ex)
              {
                this._logProvider.LogWrite("Infinite tread stop", LogSeverity.Debug);
                throw;
              }
              this.CheckConnectionsRoll(this._timeout, this._maxRetries, this._retriesDelay);
              Thread.Sleep((int) GatewayConnectionPool._currentInterval);
            }
          }), GatewayConnectionPool._token.Token, TaskCreationOptions.LongRunning, TaskScheduler.Default);
        }
        ++GatewayConnectionPool._useAgeCounter;
        this._logProvider.LogWrite(string.Format("Incrementing UsageCounter. New value is {0}", (object) GatewayConnectionPool._useAgeCounter), LogSeverity.Debug);
      }
      this._isPoolRunning = true;
    }

    private async Task ParserConfigGatewayUrlsAsync(string configUrls)
    {
      if (string.IsNullOrEmpty(configUrls))
        throw new ArgumentException("A value for gatewayurl must be specified in the deployment descriptor or gatewayurl has errors");
      string[] strArray1 = this._gatewayUrls.Split(',', StringSplitOptions.None);
      GatewayConnectionPool.FirstUrl = strArray1.Length != 0 ? strArray1[0] : (string) null;
      string[] strArray = strArray1;
      for (int index = 0; index < strArray.Length; ++index)
      {
        string item = strArray[index];
        try
        {
          if (Uri.IsWellFormedUriString(item + "/gateway/evaluate", UriKind.RelativeOrAbsolute))
          {
            if (await this.CheckConnectionAsync(item).ConfigureAwait(false))
              this._poolGatewayUrls.Enqueue(item);
          }
          else
            continue;
        }
        catch (Exception ex)
        {
          throw new ArgumentException("A value for gatewayurl must be specified in the deployment descriptor or gatewayurl has errors");
        }
        item = (string) null;
      }
      strArray = (string[]) null;
    }

    private async Task<bool> CheckConnectionAsync(string url)
    {
      ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
      HttpWebRequest http = WebRequest.CreateHttp(url.TrimEnd('/') + "/alive.txt");
      http.Method = "GET";
      http.Timeout = this._timeout;
      http.KeepAlive = false;
      try
      {
        using (WebResponse webResponse = await http.GetResponseAsync().ConfigureAwait(false))
        {
          if (((HttpWebResponse) webResponse).StatusCode == HttpStatusCode.OK)
          {
            webResponse.Close();
            return true;
          }
          webResponse.Close();
        }
      }
      catch
      {
      }
      return false;
    }

    private async Task<string> FailoverProcessingAsync(string url)
    {
      GatewayConnectionPool gatewayConnectionPool1 = this;
      if (string.IsNullOrEmpty(url))
        return (string) null;
      if (!gatewayConnectionPool1._gatewayFailoverEnable)
        return url;
      DateTime utcNow = DateTime.UtcNow;
      if ((utcNow.TimeOfDay - gatewayConnectionPool1._lastCheckTime).TotalMilliseconds >= (double) gatewayConnectionPool1._intervalCheckUrl)
      {
        gatewayConnectionPool1._logProvider.LogWrite(string.Format("Try switch to first url {0}", (object) GatewayConnectionPool.FirstUrl), LogSeverity.Info);
        if (await gatewayConnectionPool1.CheckConnectionAsync(GatewayConnectionPool.FirstUrl).ConfigureAwait(false))
        {
          GatewayConnectionPool gatewayConnectionPool2 = gatewayConnectionPool1;
          utcNow = DateTime.UtcNow;
          TimeSpan timeOfDay = utcNow.TimeOfDay;
          gatewayConnectionPool2._lastCheckTime = timeOfDay;
          gatewayConnectionPool1._logProvider.LogWrite(string.Format("Switched to url {0}", (object) GatewayConnectionPool.FirstUrl), LogSeverity.Info);
          GatewayConnectionPool.CurrentUrl = GatewayConnectionPool.FirstUrl;
          return GatewayConnectionPool.FirstUrl;
        }
        GatewayConnectionPool gatewayConnectionPool3 = gatewayConnectionPool1;
        utcNow = DateTime.UtcNow;
        TimeSpan timeOfDay1 = utcNow.TimeOfDay;
        gatewayConnectionPool3._lastCheckTime = timeOfDay1;
      }
      return url;
    }

    private long CalculateCurrentInterval(int candidateSize, int availableSize)
    {
      if (availableSize * 100 / candidateSize > this._qourum)
        return this._normalInterval;
      return this._urgentInterval;
    }

    private void CheckConnectionsRoll(int timeout = 10000, int maxRetries = 5, int retriesDelay = 100)
    {
      if (!GatewayConnectionPool._isInitialized)
        return;
      string[] strArray = this._gatewayUrls.Split(',', StringSplitOptions.None);
      this._logProvider.LogWrite(string.Format("Checking connection pools. Candidate size is {0}", (object) strArray.Length), LogSeverity.Info);
      List<string> source = new List<string>();
      foreach (string str in strArray)
      {
        int num = maxRetries;
        string requestUriString = str.TrimEnd('/') + "/alive.txt";
        while (num > 0)
        {
          Interlocked.Decrement(ref num);
          this._logProvider.LogWrite(string.Format("There are still attempts to check urls from gatewayurl {0}", (object) num), LogSeverity.Info);
          ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
          HttpWebRequest httpWebRequest = (HttpWebRequest) WebRequest.Create(requestUriString);
          httpWebRequest.Method = "GET";
          httpWebRequest.Timeout = timeout;
          httpWebRequest.KeepAlive = false;
          try
          {
            using (HttpWebResponse response = (HttpWebResponse) httpWebRequest.GetResponse())
            {
              if (response.StatusCode == HttpStatusCode.OK)
              {
                source.Add(str.TrimEnd('/'));
                response.Close();
                break;
              }
              response.Close();
            }
          }
          catch (WebException ex)
          {
            this._logProvider.LogWrite("Connection URL " + str + " is not avaialble. " + ex.Message + " StackTrace: " + ex.StackTrace, LogSeverity.Info);
            this._logProvider.LogWrite("Connection URL " + str + " is not avaialble. " + ex.Message + " StackTrace: " + ex.StackTrace, LogSeverity.Debug);
          }
          catch (Exception ex)
          {
            this._logProvider.LogWrite("General Exception with pool url. " + ex.Message + " StackTrace: " + ex.StackTrace, LogSeverity.Info);
            this._logProvider.LogWrite("General Exception with pool url. " + ex.Message + " StackTrace: " + ex.StackTrace, LogSeverity.Debug);
          }
          Thread.Sleep(retriesDelay);
          Interlocked.CompareExchange(ref num, 0, 0);
        }
      }
      GatewayConnectionPool._currentInterval = this.CalculateCurrentInterval(strArray.Length, source.Count);
      if (source.Any<string>())
        this._logProvider.LogWrite("Connection Pool validation is completed. Size is " + (object) source.Count, LogSeverity.Info);
      else
        this._logProvider.LogWrite("No gateway URL is available at this time.", LogSeverity.Warn);
      if (source.Count <= 0)
        return;
      this._poolGatewayUrls = new ConcurrentQueue<string>((IEnumerable<string>) source);
    }
  }
}
