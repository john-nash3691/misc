﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.ConnectionPool.IGatewayConnectionPool
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using System.Threading.Tasks;

namespace SSORestIISModule.Core.ConnectionPool
{
  public interface IGatewayConnectionPool
  {
    Task InitAsync();

    Task<string> GetCurrentRequestUrlAsync(bool next = false, bool is510Request = false);

    void Stop();
  }
}
