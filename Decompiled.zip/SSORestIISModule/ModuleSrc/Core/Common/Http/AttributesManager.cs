﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Common.Http.AttributesManager
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SSORestIISModule.Core.Common.Http
{
  public class AttributesManager
  {
    public static void SetAttribute(HttpContext context, string key, string value)
    {
      Dictionary<string, string> dictionary = !context.Items.ContainsKey((object) "sso-attributes") ? new Dictionary<string, string>() : (Dictionary<string, string>) context.Items[(object) "sso-attributes"];
      if (dictionary.ContainsKey(key))
        dictionary[key] = value;
      else
        dictionary.Add(key, value);
      context.Items[(object) "sso-attributes"] = (object) dictionary;
    }

    public static Dictionary<string, string> GetAllAttributes(HttpContext context)
    {
      Dictionary<string, string> dictionary = new Dictionary<string, string>();
      if (context.Items.ContainsKey((object) "sso-attributes"))
        dictionary = ((IEnumerable<KeyValuePair<string, string>>) context.Items[(object) "sso-attributes"]).Where<KeyValuePair<string, string>>((Func<KeyValuePair<string, string>, bool>) (kv => kv.Value != null)).ToDictionary<KeyValuePair<string, string>, string, string>((Func<KeyValuePair<string, string>, string>) (k => k.Key), (Func<KeyValuePair<string, string>, string>) (v => v.Value));
      return dictionary;
    }
  }
}
