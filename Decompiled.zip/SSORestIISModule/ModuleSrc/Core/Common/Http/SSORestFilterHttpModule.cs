﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Common.Http.SSORestFilterHttpModule
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using SSORestIISModule.Core.Common.Log.Enum;
using SSORestIISModule.Core.Common.Module;
using SSORestIISModule.Core.ConnectionPool;
using SSORestIISModule.Core.InternalLogger;
using SSORestIISModule.Core.Security;
using SSORestIISModule.ExchangeMessage.Processor.HandshakeProcessor;
using SSORestIISModule.ExchangeMessage.Processor.RequestProcessor;
using SSORestIISModule.ExchangeMessage.Processor.ResponseProcessor;
using System;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

namespace SSORestIISModule.Core.Common.Http
{
  public class SSORestFilterHttpModule : AbstractModule
  {
    private readonly RequestDelegate _next;
    private readonly string _version;
    private readonly Lazy<RequestProcessor> _requestProcessor;
    private readonly Lazy<GatewayConnectionPool> _connectionPool;
    private readonly IHostingEnvironment _environment;

    public SSORestFilterHttpModule(RequestDelegate next, IHostingEnvironment environment)
    {
      this._next = next;
      this._environment = environment;
      Assembly assembly = Assembly.GetAssembly(this.GetType());
      if (assembly != (Assembly) null)
        this._version = assembly.GetName().Version.ToString();
      this.LogProvider.LogWrite(string.Format("Loaded SSORest filter ({0})", (object) this._version), LogSeverity.Info);
      new Lazy<ISecurityProvider>((Func<ISecurityProvider>) (() => (ISecurityProvider) new SecurityProvider(this.ConfigParam.DisableGatewayCertCheck, this.ConfigParam.SecurityProtocol)), LazyThreadSafetyMode.ExecutionAndPublication).Value.ApplySecuritySettings();
      this._connectionPool = new Lazy<GatewayConnectionPool>((Func<GatewayConnectionPool>) (() => (GatewayConnectionPool) new GatewayConnectionPool((ILogProvider) new LogProvider(), this.ConfigParam.GatewayUrls, this.ConfigParam.GatewayFailoverEnable, this.ConfigParam.ConnectionTimeout, this.ConfigParam.MaxRetries, this.ConfigParam.RetriesDelay, this.ConfigParam.IntervalCheckUrl, this.ConfigParam.Expect100Continue, this.ConfigParam.MaxConnections, this.ConfigParam.NormalInterval, this.ConfigParam.UrgentInterval, this.ConfigParam.Qourum, this.ConfigParam.ConnectionPoolEnable)), true);
      this._connectionPool.Value.InitAsync().ConfigureAwait(false).GetAwaiter().GetResult();
      Lazy<IHandshakeProcessor> handshakeProcessor = new Lazy<IHandshakeProcessor>((Func<IHandshakeProcessor>) (() => (IHandshakeProcessor) new SSORestIISModule.ExchangeMessage.Processor.HandshakeProcessor.HandshakeProcessor()), true);
      Lazy<IRequestFactory> requestFactory = new Lazy<IRequestFactory>((Func<IRequestFactory>) (() => (IRequestFactory) new RequestFactory()), true);
      this._requestProcessor = new Lazy<RequestProcessor>((Func<RequestProcessor>) (() => (RequestProcessor) new SSORestIISModule.ExchangeMessage.Processor.RequestProcessor.RequestProcessor((IResponseProcessor) new SSORestIISModule.ExchangeMessage.Processor.ResponseProcessor.ResponseProcessor(this._connectionPool.Value, handshakeProcessor.Value, requestFactory.Value))), true);
      new LogProvider().LogWrite("SSORestFilterHttpModule()", LogSeverity.Debug);
      this.LogProvider.LogWrite(string.Format("ConnectionTimeout {0}", (object) this.ConfigParam.ConnectionTimeout), LogSeverity.Info);
      this.LogProvider.LogWrite(string.Format("MaxConnections {0}", (object) this.ConfigParam.MaxConnections), LogSeverity.Info);
      this.LogProvider.LogWrite(string.Format("Expect100Continue {0}", (object) this.ConfigParam.Expect100Continue), LogSeverity.Info);
      this.LogProvider.LogWrite(string.Format("MaxRetries {0}", (object) this.ConfigParam.MaxRetries), LogSeverity.Info);
      this.LogProvider.LogWrite(string.Format("RetriesDelay {0}", (object) this.ConfigParam.RetriesDelay), LogSeverity.Info);
      this.LogProvider.LogWrite(string.Format("SendFormParameters {0}", (object) this.ConfigParam.SendFormParameters), LogSeverity.Info);
      this.LogProvider.LogWrite(string.Format("DisableVersionHeaders {0}", (object) this.ConfigParam.DisableVersionHeaders), LogSeverity.Info);
      this.LogProvider.LogWrite("SendRequestHeaders " + this.ConfigParam.SendRequestHeaders, LogSeverity.Info);
      this.LogProvider.LogWrite("IgnoreRequestHeaders " + this.ConfigParam.IgnoreRequestHeaders, LogSeverity.Info);
      this.LogProvider.LogWrite(string.Format("GatewayFailoverEnable {0}", (object) this.ConfigParam.GatewayFailoverEnable), LogSeverity.Info);
      this.LogProvider.LogWrite(string.Format("DisableGatewayCertCheck {0}", (object) this.ConfigParam.DisableGatewayCertCheck), LogSeverity.Info);
      this.LogProvider.LogWrite(string.Format("IntervalCheckUrl {0}", (object) this.ConfigParam.IntervalCheckUrl), LogSeverity.Info);
      this.LogProvider.LogWrite(string.Format("TransactionTimeWarningThreshold {0}", (object) this.ConfigParam.TransactionTimeWarningThreshold), LogSeverity.Info);
      this.LogProvider.LogWrite(string.Format("ConnectionPoolEnable {0}", (object) this.ConfigParam.ConnectionPoolEnable), LogSeverity.Info);
      this.LogProvider.LogWrite("SecurityProtocol " + this.ConfigParam.SecurityProtocol, LogSeverity.Info);
    }

    public async Task InvokeAsync(HttpContext context)
    {
      try
      {
        new LogProvider().LogWrite(nameof (InvokeAsync), LogSeverity.Debug);
        this._requestProcessor.Value.ContextOnBeginRequest(context);
        this._requestProcessor.Value.PreSendRequestHeaders(context);
        if (context.Response.HasStarted)
          return;
        await this._next.Invoke(context);
      }
      catch
      {
      }
    }
  }
}
