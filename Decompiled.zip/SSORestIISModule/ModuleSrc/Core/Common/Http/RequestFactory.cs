﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Http.Headers;
using Microsoft.Extensions.Primitives;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using SFTIHM.Filter_dotnetcore;
using SSORestIISModule.Core.Common.Gateway;
using SSORestIISModule.Core.Common.Log.Enum;
using SSORestIISModule.Core.Common.Module;
using SSORestIISModule.Core.Common.Utility;
using SSORestIISModule.Core.ConnectionPool;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using SSORestIISModule.Core.Common.Extensions;

namespace SSORestIISModule.Core.Common.Http
{
    public class RequestFactory : AbstractModule, IRequestFactory
    {
        public HttpWebRequest CreateRequestToGateway(HttpContext context, string url)
        {
            HttpRequest request = context.Request;
            bool sendFormParameters = this.ConfigParam.SendFormParameters;
            string[] array1 = ((IEnumerable<string>)this.ConfigParam.SendRequestHeaders.Split(',', StringSplitOptions.None)).Where<string>((Func<string, bool>)(d => !string.IsNullOrEmpty(d))).Select<string, string>((Func<string, string>)(d => d.ToUpper())).ToArray<string>();
            string[] array2 = ((IEnumerable<string>)this.ConfigParam.IgnoreRequestHeaders.Split(',', StringSplitOptions.None)).Where<string>((Func<string, bool>)(d => !string.IsNullOrEmpty(d))).Select<string, string>((Func<string, string>)(d => d.ToUpper())).ToArray<string>();
            if (!this.ConfigParam.DisableVersionHeaders)
                array1 = ((IEnumerable<string>)array1).Concat<string>((IEnumerable<string>)new string[1]
                {
          "X-IDFC-SSO-VERSION=Dot_net-" + (object) Assembly.GetExecutingAssembly().GetName().Version
                }).ToArray<string>();
            RequestHeaderPoolManager headerPoolManager = new RequestHeaderPoolManager(array1, array2);
            SSOZonePoolManager ssoZonePoolManager = new SSOZonePoolManager(((IEnumerable<string>)this.ConfigParam.SSOZone.Split(',', StringSplitOptions.None)).Where<string>((Func<string, bool>)(d => !string.IsNullOrEmpty(d))).ToArray<string>());
            RequestHeaders requestHeaders1 = new RequestHeaders(request.Headers);
            string str1 = !string.IsNullOrEmpty(request.Headers["Content-Encoding"]) ? request.Headers["Content-Encoding"].ToString() : "utf-8";
            string[] strArray1;
            if (requestHeaders1.AcceptLanguage == null)
                strArray1 = new string[1] { string.Empty };
            else
                strArray1 = ((IEnumerable<StringWithQualityHeaderValue>)requestHeaders1.AcceptLanguage).Select<StringWithQualityHeaderValue, string>((Func<StringWithQualityHeaderValue, string>)(k => ((object)k).ToString())).ToArray<string>();
            string[] strArray2 = strArray1;
            object obj1;
            object obj2;

            if (sendFormParameters)
            {
                Dictionary<string, string> allAttributes1 = AttributesManager.GetAllAttributes(context);
                string method1 = request.Method;
                string displayUrl1 = UriHelper.GetDisplayUrl(request);
                string protocol1 = request.Protocol;
                string str2 = str1;
                long? contentLength1 = request.ContentLength;
                string contentType1 = request.ContentType;
                string contextPath1 = Utils.GetContextPath(request);
                string str3 = context.Connection.LocalIpAddress.ToString();
                string fqdn1 = Utils.GetFQDN();
                HostString host1 = request.Host;
                int? port = host1.Port;
                int num1 = port ?? context.Connection.LocalPort;
                string str4 = context.Connection.RemoteIpAddress.ToString();
                string str5 = context.Connection.RemoteIpAddress.ToString();
                string str6 = context.Connection.RemotePort.ToString();
                int num2 = request.IsHttps ? 1 : 0;
                string scheme1 = request.Scheme;
                HostString host2 = request.Host;
                string host3 = host2.Host;
                HostString host4 = request.Host;
                port = host4.Port;
                int num3 = port ?? (request.IsHttps ? 443 : 80);
                string empty1 = string.Empty;
                string[] strArray3 = strArray2;
                Dictionary<string, string[]> requestHeaders2 = headerPoolManager.GetRequestHeaders(request.Headers.ToDictionary(a => a.Key, a => a.Value.ToArray()));
                Dictionary<string, string[]> neededParams = Utils.GetNeededParams(request);
                List<JavaCookie> requestCookies1 = ssoZonePoolManager.GetRequestCookies((IEnumerable<JavaCookie>)request.Cookies.ToJavaCookiesList(""));
                obj1 = (object)new
                {
                    attributes = allAttributes1,
                    method = method1,
                    url = displayUrl1,
                    protocol = protocol1,
                    characterEncoding = str2,
                    contentLength = contentLength1,
                    contentType = contentType1,
                    contextPath = contextPath1,
                    localAddr = str3,
                    localName = fqdn1,
                    localPort = num1,
                    remoteAddr = str4,
                    remoteHost = str5,
                    remotePort = str6,
                    secure = (num2 != 0),
                    sessionidfromcookie = false,
                    sessionidfromurl = false,
                    sessionidvalid = false,
                    scheme = scheme1,
                    serverName = host3,
                    serverPort = num3,
                    servletPath = empty1,
                    locales = strArray3,
                    headers = requestHeaders2,
                    parameters = neededParams,
                    cookies = requestCookies1
                };
                Dictionary<string, string> allAttributes2 = AttributesManager.GetAllAttributes(context);
                string method2 = request.Method;
                string displayUrl2 = UriHelper.GetDisplayUrl(request);
                string protocol2 = request.Protocol;
                string str7 = str1;
                long? contentLength2 = request.ContentLength;
                string contentType2 = request.ContentType;
                string contextPath2 = Utils.GetContextPath(request);
                string str8 = context.Connection.LocalIpAddress.ToString();
                string fqdn2 = Utils.GetFQDN();
                HostString host5 = request.Host;
                port = host5.Port;
                int num4 = port ?? context.Connection.LocalPort;
                string str9 = context.Connection.RemoteIpAddress.ToString();
                string str10 = context.Connection.RemoteIpAddress.ToString();
                string str11 = context.Connection.RemotePort.ToString();
                int num5 = request.IsHttps ? 1 : 0;
                string scheme2 = request.Scheme;
                host5 = request.Host;
                string host6 = host5.Host;
                host5 = request.Host;
                port = host5.Port;
                int num6 = port ?? (request.IsHttps ? 443 : 80);
                string empty2 = string.Empty;
                string[] strArray4 = strArray2;
                Dictionary<string, string[]> requestHeaders3 = headerPoolManager.GetRequestHeaders(((IEnumerable<KeyValuePair<string, StringValues>>)request.Headers).ToDictionary<KeyValuePair<string, StringValues>, string, string[]>((Func<KeyValuePair<string, StringValues>, string>)(a => a.Key), (Func<KeyValuePair<string, StringValues>, string[]>)(a =>
             {
                 return a.Value.ToArray();
             })));
                Dictionary<string, string[]> dictionary = this.PasswordMask(Utils.GetNeededParams(request));
                List<JavaCookie> requestCookies2 = ssoZonePoolManager.GetRequestCookies((IEnumerable<JavaCookie>)request.Cookies.ToJavaCookiesList(""));
                obj2 = (object)new
                {
                    attributes = allAttributes2,
                    method = method2,
                    url = displayUrl2,
                    protocol = protocol2,
                    characterEncoding = str7,
                    contentLength = contentLength2,
                    contentType = contentType2,
                    contextPath = contextPath2,
                    localAddr = str8,
                    localName = fqdn2,
                    localPort = num4,
                    remoteAddr = str9,
                    remoteHost = str10,
                    remotePort = str11,
                    secure = (num5 != 0),
                    sessionidfromcookie = false,
                    sessionidfromurl = false,
                    sessionidvalid = false,
                    scheme = scheme2,
                    serverName = host6,
                    serverPort = num6,
                    servletPath = empty2,
                    locales = strArray4,
                    headers = requestHeaders3,
                    parameters = dictionary,
                    cookies = requestCookies2
                };
            }
            else
            {
                Dictionary<string, string> allAttributes1 = AttributesManager.GetAllAttributes(context);
                string method1 = request.Method;
                string displayUrl1 = UriHelper.GetDisplayUrl(request);
                string protocol1 = request.Protocol;
                string str2 = str1;
                string contextPath1 = Utils.GetContextPath(request);
                string str3 = context.Connection.LocalIpAddress.ToString();
                string fqdn1 = Utils.GetFQDN();
                HostString host1 = request.Host;
                int? port = host1.Port;
                int num1 = port ?? context.Connection.LocalPort;
                string str4 = context.Connection.RemoteIpAddress.ToString();
                string str5 = context.Connection.RemoteIpAddress.ToString();
                string str6 = context.Connection.RemotePort.ToString();
                int num2 = request.IsHttps ? 1 : 0;
                string scheme1 = request.Scheme;
                HostString host2 = request.Host;
                string host3 = host2.Host;
                HostString host4 = request.Host;
                port = host4.Port;
                int num3 = port ?? (request.IsHttps ? 443 : 80);
                string empty1 = string.Empty;
                string[] strArray3 = strArray2;
                Dictionary<string, string[]> requestHeaders2 = headerPoolManager.GetRequestHeaders(((IEnumerable<KeyValuePair<string, StringValues>>)request.Headers).ToDictionary<KeyValuePair<string, StringValues>, string, string[]>((Func<KeyValuePair<string, StringValues>, string>)(a => a.Key), (Func<KeyValuePair<string, StringValues>, string[]>)(a => a.Value.ToArray())));
                Dictionary<string, string[]> neededParams = Utils.GetNeededParams(request);
                List<JavaCookie> requestCookies1 = ssoZonePoolManager.GetRequestCookies((IEnumerable<JavaCookie>)request.Cookies.ToJavaCookiesList(""));
                obj1 = (object)new
                {
                    attributes = allAttributes1,
                    method = method1,
                    url = displayUrl1,
                    protocol = protocol1,
                    characterEncoding = str2,
                    contextPath = contextPath1,
                    localAddr = str3,
                    localName = fqdn1,
                    localPort = num1,
                    remoteAddr = str4,
                    remoteHost = str5,
                    remotePort = str6,
                    secure = (num2 != 0),
                    sessionidfromcookie = false,
                    sessionidfromurl = false,
                    sessionidvalid = false,
                    scheme = scheme1,
                    serverName = host3,
                    serverPort = num3,
                    servletPath = empty1,
                    locales = strArray3,
                    headers = requestHeaders2,
                    parameters = neededParams,
                    cookies = requestCookies1
                };
                Dictionary<string, string> allAttributes2 = AttributesManager.GetAllAttributes(context);
                string method2 = request.Method;
                string displayUrl2 = UriHelper.GetDisplayUrl(request);
                string protocol2 = request.Protocol;
                string str7 = str1;
                string contextPath2 = Utils.GetContextPath(request);
                string str8 = context.Connection.LocalIpAddress.ToString();
                string fqdn2 = Utils.GetFQDN();
                HostString host5 = request.Host;
                port = host5.Port;
                int num4 = port ?? context.Connection.LocalPort;
                string str9 = context.Connection.RemoteIpAddress.ToString();
                string str10 = context.Connection.RemoteIpAddress.ToString();
                string str11 = context.Connection.RemotePort.ToString();
                int num5 = request.IsHttps ? 1 : 0;
                string scheme2 = request.Scheme;
                HostString host6 = request.Host;
                string host7 = host6.Host;
                HostString host8 = request.Host;
                port = host8.Port;
                int num6 = port ?? (request.IsHttps ? 443 : 80);
                string empty2 = string.Empty;
                string[] strArray4 = strArray2;
                Dictionary<string, string[]> requestHeaders3 = headerPoolManager.GetRequestHeaders(((IEnumerable<KeyValuePair<string, StringValues>>)request.Headers).ToDictionary<KeyValuePair<string, StringValues>, string, string[]>((Func<KeyValuePair<string, StringValues>, string>)(a => a.Key), (Func<KeyValuePair<string, StringValues>, string[]>)(a =>
             {
                 return a.Value.ToArray();
             })));
                Dictionary<string, string[]> dictionary = this.PasswordMask(Utils.GetNeededParams(request));
                List<JavaCookie> requestCookies2 = ssoZonePoolManager.GetRequestCookies((IEnumerable<JavaCookie>)request.Cookies.ToJavaCookiesList(""));
                obj2 = (object)new
                {
                    attributes = allAttributes2,
                    method = method2,
                    url = displayUrl2,
                    protocol = protocol2,
                    characterEncoding = str7,
                    contextPath = contextPath2,
                    localAddr = str8,
                    localName = fqdn2,
                    localPort = num4,
                    remoteAddr = str9,
                    remoteHost = str10,
                    remotePort = str11,
                    secure = (num5 != 0),
                    sessionidfromcookie = false,
                    sessionidfromurl = false,
                    sessionidvalid = false,
                    scheme = scheme2,
                    serverName = host7,
                    serverPort = num6,
                    servletPath = empty2,
                    locales = strArray4,
                    headers = requestHeaders3,
                    parameters = dictionary,
                    cookies = requestCookies2
                };
            }
            string str12 = JsonConvert.SerializeObject(obj1);
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            HttpWebRequest http = WebRequest.CreateHttp(url);
            http.Method = "POST";
            http.ContentType = "application/json";
            http.KeepAlive = false;
            http.Timeout = this.ConfigParam.ConnectionTimeout;
            if (Utils.CheckHttpConnection(url) == HttpConnectionType.HTTPS)
            {
                bool isPathFound;
                string trustStore = this.GetTrustStore(this.ConfigParam.TrustStore, out isPathFound);
                string trustStorePass = this.ConfigParam.TrustStorePass;
                try
                {
                    if (!isPathFound)
                        throw new Exception("Can't read SSL cert file");
                    X509Certificate2Collection certificate2Collection = new X509Certificate2Collection();
                    certificate2Collection.Import(trustStore, trustStorePass, X509KeyStorageFlags.PersistKeySet);
                    http.ClientCertificates.AddRange((X509CertificateCollection)certificate2Collection);
                }
                catch (Exception ex)
                {
                    this.LogProvider.LogWrite(ex, "Can't read SSL cert file", LogSeverity.Debug);
                    http.ClientCertificates.Clear();
                    if (!this.ConfigParam.DisableGatewayCertCheck)
                        throw new ArgumentException(ex.Message, ex);
                }
            }
            if (this.ConfigParam.ProxyEnable)
            {
                string str2 = this.ConfigParam.ProxyScheme + "://" + this.ConfigParam.ProxyHost + ":" + (object)this.ConfigParam.ProxyPort;
                if (Uri.IsWellFormedUriString(str2, UriKind.RelativeOrAbsolute))
                    http.Proxy = (IWebProxy)new WebProxy(str2);
                else
                    this.LogProvider.LogWrite("Invalid parameters were provided for the proxy, no proxy will be used", LogSeverity.Debug);
            }
            using (StreamWriter streamWriter = new StreamWriter(http.GetRequestStream()))
            {
                streamWriter.Write(str12);
                streamWriter.Close();
            }
            this.LogProvider.LogWrite("Request details" + Environment.NewLine + JsonConvert.SerializeObject(obj2, (Formatting)1), LogSeverity.Debug);
            return http;
        }

        private string GetTrustStore(string store, out bool isPathFound)
        {
            isPathFound = false;
            string fileName = Path.GetFileName(store);
            string str1 = SSORestFilterHttpModuleExtensions._environment.WebRootPath ?? SSORestFilterHttpModuleExtensions._environment.ContentRootPath;
            List<string> stringList1 = new List<string>();
            stringList1.Add(store);
            List<string> stringList2 = stringList1;
            string str2;
            if (Environment.GetEnvironmentVariable("HOME") == null)
                str2 = "C:\\" + fileName.TrimEnd('\\', '/');
            else
                str2 = Environment.GetEnvironmentVariable("HOME").TrimEnd('\\') + "\\" + fileName.TrimEnd('\\', '/');
            stringList2.Add(str2);
            stringList1.Add(str1.TrimEnd('/', '/') + "/" + fileName.TrimEnd('/', '/'));
            stringList1.Add(str1.TrimEnd('\\') + "\\" + fileName.TrimEnd('\\', '/'));
            stringList1.Add(str1.TrimEnd('\\') + "\\BIN\\" + fileName.TrimEnd('\\', '/'));
            stringList1.Add(str1.TrimEnd('\\', '/') + "\\" + fileName.TrimEnd('\\', '/'));
            List<string> stringList3 = stringList1;
            this.LogProvider.LogWrite("Root Path for App, Config, and Store: " + str1, LogSeverity.Debug);
            foreach (string path in stringList3)
            {
                if (this.CheckPath(path))
                {
                    isPathFound = true;
                    return path;
                }
            }
            return store;
        }

        private bool CheckPath(string path)
        {
            this.LogProvider.LogWrite(string.Format("Check path {0}", (object)path), LogSeverity.Info);
            if (System.IO.File.Exists(path))
            {
                this.LogProvider.LogWrite(string.Format("Path {0} is valid", (object)path), LogSeverity.Info);
                return true;
            }
            this.LogProvider.LogWrite(string.Format("Path {0} is invalid", (object)path), LogSeverity.Info);
            this.LogProvider.LogWrite(string.Format("Path {0} is invalid", (object)path), LogSeverity.Error);
            return false;
        }

        private Dictionary<string, string[]> PasswordMask(Dictionary<string, string[]> param)
        {
            if (param != null)
            {
                if (param.Count != 0)
                {
                    try
                    {
                        if (param.ContainsKey("PASSWORD"))
                        {
                            string[] strArray = param["PASSWORD"];
                            if (strArray != null)
                            {
                                for (int index = 0; index < strArray.Length; ++index)
                                    strArray[index] = new string(new char[3]
                                    {
                    '*',
                    '*',
                    '*'
                                    });
                            }
                        }
                    }
                    catch
                    {
                    }
                    return param;
                }
            }
            return param;
        }
    }
}
