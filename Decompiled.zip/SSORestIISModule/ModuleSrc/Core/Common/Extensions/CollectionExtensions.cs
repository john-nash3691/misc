﻿using Microsoft.AspNetCore.Http;
using SSORestIISModule.Core.Common.Gateway;
using SSORestIISModule.Core.Common.Utility;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;

namespace SSORestIISModule.Core.Common.Extensions
{
    public static class CollectionExtensions
    {
        public static Dictionary<string, string[]> ToDictionary(
          this NameValueCollection nameValueCollection)
        {
            if (nameValueCollection == null || !nameValueCollection.HasKeys())
                return new Dictionary<string, string[]>();
            return ((IEnumerable<string>)nameValueCollection.AllKeys).Where<string>((Func<string, bool>)(keyStr =>
          {
              if (keyStr != null)
                  return nameValueCollection[keyStr] != null;
              return false;
          })).ToDictionary<string, string, string[]>((Func<string, string>)(keyStr => keyStr), (Func<string, string[]>)(keyStr => new string[1]
    {
        nameValueCollection[keyStr]
          }));
        }

        public static List<JavaCookie> ToJavaCookiesList(
          this IRequestCookieCollection collection,
          string domain = "")
        {
            List<JavaCookie> javaCookieList = new List<JavaCookie>();
            foreach (string key in (IEnumerable<string>)collection.Keys)
            {
                if (!string.IsNullOrEmpty(collection[key]))
                {
                    string rCookie = key + "=" + collection[key] + ";";
                    if (!string.IsNullOrEmpty(domain))
                        rCookie = rCookie + " domain=" + domain + ";";
                    if (rCookie != null)
                    {
                        JavaCookie javaCookie = CollectionExtensions.GetJavaCookie(rCookie);
                        if (javaCookie != null)
                            javaCookieList.Add(javaCookie);
                    }
                }
            }
            return javaCookieList;
        }

        public static JavaCookie GetJavaCookie(string rCookie)
        {
            Cookie rawCookie = CollectionExtensions.ParseRawCookie(rCookie);
            if (rawCookie == null)
                return (JavaCookie)null;
            return new JavaCookie()
            {
                Name = rawCookie.Name,
                Value = rawCookie.Value,
                Secure = rawCookie.Secure,
                MaxAge = Utils.ConvertExpiresToMaxAge(rawCookie.Expires),
                Domain = rawCookie.Domain,
                HttpOnly = rawCookie.HttpOnly
            };
        }

        public static Cookie ParseRawCookie(string rawCookie)
        {
            string[] strArray = rawCookie.Split(';', StringSplitOptions.None)[0].Split('=', StringSplitOptions.None);
            if (strArray.Length < 2)
                return (Cookie)null;
            string name = strArray[0].Trim();
            string str = strArray[1].Trim();
            if (rawCookie.Contains("domain="))
                strArray[2].Trim();
            return new Cookie(name, WebUtility.HtmlDecode(str));
        }
    }
}
