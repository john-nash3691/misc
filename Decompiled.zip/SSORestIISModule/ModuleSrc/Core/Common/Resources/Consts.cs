﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Common.Resources.Consts
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

namespace SSORestIISModule.Core.Common.Resources
{
  internal static class Consts
  {
    public const string FccFileStore = "fcc_file_login";
    public const string FccFileTimeStampStore = "fcc_file_login_timestamp";
    public const string CookiesItemsStorage = "idf_100cookies";
    public const string GatewayTokenName = "gatewayToken";
    public const string ContentRequestAttribute = "content";
    public const string ContentTimestampRequestAttribute = "contentTimestamp";
    public const string AttributesKey = "sso-attributes";
    public const string ConfigGlobalFileName = "SSORestIISModule.global.config";
    public const string ConfigAppFileName = "SSORestIISModule.app.config";
    public const string DefaultConfigSectionName = "default_module_config";
    public const string SignatureNeeded = "Signature Needed";
  }
}
