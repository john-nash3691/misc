﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Common.Resources.Messages.RequestProcessorMessages
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

namespace SSORestIISModule.Core.Common.Resources.Messages
{
  internal static class RequestProcessorMessages
  {
    public const string InvalidParametersProxy = "Invalid parameters were provided for the proxy, no proxy will be used";
    public const string RequestDetails = "Request details";
    public const string ExceptionReadingFilesForSSLContext = "Can't read SSL cert file";
    public const string PathInvalid = "Path {0} is invalid";
    public const string PathValid = "Path {0} is valid";
    public const string CheckPath = "Check path {0}";
  }
}
