﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Common.Resources.Messages.HandshakeProcessorMessages
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

namespace SSORestIISModule.Core.Common.Resources.Messages
{
  internal static class HandshakeProcessorMessages
  {
    public const string ErrorGeneratingSignature = "ERROR generating signature";
    public const string SecretKeyIsNotDefined = "Filter's Secret key is not defined";
    public const string PluginIdIsNotDefined = "Plugin ID is not defined";
    public const string NotAbleToGetChallengeFromGateway = "Not able to get challenge from Gateway.No challenge response will be sent";
  }
}
