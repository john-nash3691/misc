﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Common.Resources.Messages.GatewayConnectionPoolMessages
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

namespace SSORestIISModule.Core.Common.Resources.Messages
{
  public static class GatewayConnectionPoolMessages
  {
    public const string GatewayUrlsDoNotDefined = "A value for gatewayurl must be specified in the deployment descriptor or gatewayurl has errors";
    public const string NoValidGatewayUrlsWereFound = "No valid gatewayurls were found";
    public const string ThereAreNotAvailableUrl = "There are not available url. Failover Max retry reached. Exiting...";
    public const string TrySwitchTo = "Try switch to first url {0}";
    public const string SwitchedTo = "Switched to url {0}";
  }
}
