﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Common.Resources.Messages.ResponseProcessorMessages
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

namespace SSORestIISModule.Core.Common.Resources.Messages
{
  internal static class ResponseProcessorMessages
  {
    public const string ThereAreNotAvailableUrls = "There are not available urls";
    public const string ThereAreNotAvailableUrlsFailover = "There are not available urls. Failover Max retry reached. Exiting...";
    public const string RequestResponseStatus = "Request response. Status {0} {1} {2}";
    public const string GatewayResponseStatedContentRequired = "Gateway response stated content required, looking for local content to supply";
    public const string ProcessingRequest = "Processing request {0} {1}";
    public const string HandleSsoRestPublicEndpointsNotImplemented = "HandleSsoRestPublicEndpoints not implemented";
    public const string ReceivedStatusCodeFromGateway = "Received {0} status code from gateway";
    public const string ResponseDetails = "Response details";
    public const string GatewayURLNotAvailable = "Gateway URL not available {0}";
    public const string ThereAreStillAttempts = "There are still attempts {0} to get successful response from gateway";
    public const string UseNextUrl = "Use next url {0}";
  }
}
