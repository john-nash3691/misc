﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Common.Module.AbstractModule
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using SSORestIISModule.Core.Configuration;
using SSORestIISModule.Core.InternalLogger;

namespace SSORestIISModule.Core.Common.Module
{
  public abstract class AbstractModule
  {
    protected readonly ILogProvider LogProvider;
    protected readonly ConfigurationModuleParameters ConfigParam;

    protected AbstractModule()
    {
      this.LogProvider = (ILogProvider) new SSORestIISModule.Core.InternalLogger.LogProvider();
      this.ConfigParam = ConfigurationProvider.GetProvider().GetConfigurationModuleParametersAsync().ConfigureAwait(false).GetAwaiter().GetResult();
    }
  }
}
