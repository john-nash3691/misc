﻿namespace SSORestIISModule.Core.Common.Cache
{
  public static class CacheConnectonPool
  {
    public static string CurrentUrl { get; set; }

    public static string FirstUrl { get; set; }
  }
}
