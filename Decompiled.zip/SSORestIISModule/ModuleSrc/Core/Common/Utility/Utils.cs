﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Common.Utility.Utils
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using Microsoft.Extensions.Primitives;
using SSORestIISModule.Core.Common.Gateway;
using SSORestIISModule.Core.Common.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Text;

namespace SSORestIISModule.Core.Common.Utility
{
  internal static class Utils
  {
    public static object FillCookiesForContext(
      IEnumerable<JavaCookie> cookies,
      object contextCookies,
      string domain)
    {
      ResponseCookies responseCookies = (ResponseCookies) null;
      Dictionary<string, string> dictionary = (Dictionary<string, string>) null;
      if (contextCookies is IRequestCookieCollection)
        dictionary = ((IEnumerable<KeyValuePair<string, string>>) contextCookies).ToDictionary<KeyValuePair<string, string>, string, string>((Func<KeyValuePair<string, string>, string>) (k => k.Key), (Func<KeyValuePair<string, string>, string>) (v => v.Value));
      if (contextCookies is ResponseCookies)
        responseCookies = (ResponseCookies) contextCookies;
      foreach (JavaCookie cookie in cookies)
      {
        if (contextCookies is IRequestCookieCollection)
        {
          Cookie httpCookie = Utils.ConvertToHttpCookie(cookie, domain);
          if (dictionary.ContainsKey(httpCookie.Name))
            dictionary[httpCookie.Name] = httpCookie.Value;
          else
            dictionary.Add(httpCookie.Name, httpCookie.Value);
        }
        else if (contextCookies is ResponseCookies)
        {
          Cookie httpCookie = Utils.ConvertToHttpCookie(cookie, domain);
          responseCookies.Delete(httpCookie.Name);
          responseCookies.Append(httpCookie.Name, httpCookie.Value);
        }
      }
      if (contextCookies is IRequestCookieCollection)
        contextCookies = (object) new RequestCookieCollection(dictionary);
      if (contextCookies is ResponseCookies)
        contextCookies = (object) responseCookies;
      return contextCookies;
    }

    public static string GetRandomString(int size)
    {
      char[] charArray = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890".ToCharArray();
      byte[] data = new byte[1];
      using (RNGCryptoServiceProvider cryptoServiceProvider = new RNGCryptoServiceProvider())
      {
        cryptoServiceProvider.GetNonZeroBytes(data);
        data = new byte[size];
        cryptoServiceProvider.GetNonZeroBytes(data);
      }
      StringBuilder stringBuilder = new StringBuilder(size);
      foreach (byte num in data)
        stringBuilder.Append(charArray[(int) num % charArray.Length]);
      return stringBuilder.ToString();
    }

    public static string HmacBase64(string input, byte[] key)
    {
      using (MemoryStream memoryStream = new MemoryStream(Encoding.UTF8.GetBytes(input)))
        return Convert.ToBase64String(new HMACSHA1(key).ComputeHash((Stream) memoryStream));
    }

    public static string GetFQDN()
    {
      string domainName = IPGlobalProperties.GetIPGlobalProperties().DomainName;
      string str = Dns.GetHostName();
      if (!str.EndsWith(domainName))
        str = str + "." + domainName;
      return str;
    }

    public static string GetContextPath(HttpRequest request)
    {
      string scheme = request.Scheme;
      HostString host1 = request.Host;
      string host2 = host1.Host;
      string str1 = scheme + "://" + host2;
      HostString host3 = request.Host;
      int? port1 = host3.Port;
      int num = request.HttpContext.User.Identity.IsAuthenticated ? 443 : 80;
      if (!(port1.GetValueOrDefault() == num & port1.HasValue))
      {
        string str2 = str1;
        int port2 = request.Host.Port.GetValueOrDefault();
        str1 = str2 + ":" + (object) port2;
      }
      return str1;
    }

    public static long ConvertExpiresToMaxAge(DateTime expires)
    {
      if (expires == DateTime.MinValue)
        return -1;
      long int64 = Convert.ToInt64((expires - DateTime.Now).TotalSeconds);
      if (int64 <= 0L)
        return -1;
      return int64;
    }

    public static Dictionary<string, string[]> GetNeededParams(HttpRequest request)
    {
      Dictionary<string, string[]> dictionary = new Dictionary<string, string[]>();
      if (request.Query == null || request.Query.Count() == 0)
        return dictionary;
      foreach (string key1 in request.Query.Keys.Select<string, string>((Func<string, string>) (x => x?.ToUpperInvariant())).Concat<string>(request.Form.Keys.Select<string, string>((Func<string, string>) (x => x?.ToUpperInvariant()))).Distinct<string>().ToList<string>())
      {
        StringValues stringValues;
        string[] strArray1;
        if (!request.Query.ContainsKey(key1))
        {
          strArray1 = new string[0];
        }
        else
        {
          stringValues =  request.Query[key1];
          strArray1 = stringValues.ToArray();
        }
        string[] strArray2 = strArray1;
        try
        {
          string[] strArray3 = strArray2;
          string[] strArray4;
          if (!request.Form.ContainsKey(key1))
          {
            strArray4 = new string[0];
          }
          else
          {
            stringValues = request.Form[key1];
            strArray4 = stringValues.ToArray();
          }
          strArray2 = ((IEnumerable<string>) strArray3).Concat<string>((IEnumerable<string>) strArray4).ToArray<string>();
        }
        catch
        {
        }
        if (key1 != null)
        {
          dictionary.Add(key1, strArray2);
        }
        else
        {
          foreach (string key2 in ((IEnumerable<string>) strArray2).Distinct<string>())
          {
            if (!dictionary.ContainsKey(key2))
              dictionary.Add(key2, new string[0]);
          }
        }
      }
      return dictionary;
    }

    public static HttpConnectionType CheckHttpConnection(string url)
    {
      if (!Uri.IsWellFormedUriString(url, UriKind.RelativeOrAbsolute))
        return HttpConnectionType.UNKNOWN;
      return new Uri(url).Scheme == Uri.UriSchemeHttps ? HttpConnectionType.HTTPS : HttpConnectionType.HTTP;
    }

    public static void FillCookiesForResponseContext(
      IEnumerable<JavaCookie> cookies,
      HttpResponse contextCookies,
      string domain)
    {
      foreach (JavaCookie cookie in cookies)
      {
        contextCookies.Cookies.Delete(cookie.Name);
        Cookie httpCookie = Utils.ConvertToHttpCookie(cookie, domain);
        contextCookies.Cookies.Append(httpCookie.Name, httpCookie.Value);
      }
    }

    public static void FillHeadersForResponseContext(
      Dictionary<string, string[]> jsonHeaders,
      HttpResponse contextCollection)
    {
      foreach (KeyValuePair<string, string[]> jsonHeader in jsonHeaders)
      {
        if (!string.Equals(jsonHeader.Key, "cookie", StringComparison.OrdinalIgnoreCase))
        {
          if (((IDictionary<string, StringValues>) contextCollection.Headers).ContainsKey(jsonHeader.Key))
            contextCollection.Headers[jsonHeader.Key]= string.Join(",", jsonHeader.Value);
          else
            ((IDictionary<string, StringValues>) contextCollection.Headers).Add(jsonHeader.Key, string.Join(",", jsonHeader.Value));
        }
      }
    }

    public static void FillHeadersForContextWithReflections(
      Dictionary<string, string[]> jsonHeaders,
      HttpRequest contextCollection)
    {
      foreach (KeyValuePair<string, string[]> jsonHeader in jsonHeaders)
      {
        if (!string.Equals(jsonHeader.Key, "cookie", StringComparison.OrdinalIgnoreCase))
        {
          if (((IDictionary<string, StringValues>) contextCollection.Headers).ContainsKey(jsonHeader.Key))
            contextCollection.Headers[jsonHeader.Key]= new StringValues(jsonHeader.Value);
          else
            ((IDictionary<string, StringValues>) contextCollection.Headers).Add(jsonHeader.Key, new StringValues(jsonHeader.Value));
        }
      }
    }

    public static void FillHeadersForServerVariables(
      Dictionary<string, string[]> jsonHeaders,
      HttpRequest contextCollection)
    {
      string[] strArray = contextCollection.Query["ALL_HTTP"].ToString().Split(new string[1]
      {
        "HTTP_"
      }, StringSplitOptions.RemoveEmptyEntries);
      Dictionary<string, string> dictionary = new Dictionary<string, string>();
      foreach (KeyValuePair<string, string[]> jsonHeader in jsonHeaders)
        dictionary.Add(jsonHeader.Key.ToUpperInvariant(), string.Join(",", jsonHeader.Value));
      foreach (string str1 in strArray)
      {
        int length = str1.IndexOf(":", StringComparison.Ordinal);
        if (length > 0)
        {
          string key = str1.Substring(0, length).ToUpperInvariant().TrimStart();
          if (!dictionary.ContainsKey(key))
          {
            string str2 = str1.Substring(length + 1).TrimEnd();
            dictionary.Add(key, str2);
          }
        }
      }
    }

    public static void FillCookieHeader(HttpRequest request)
    {
      List<string> stringList = new List<string>();
      foreach (string key in (IEnumerable<string>) request.Cookies.Keys)
        stringList.Add(string.Format("{0}={1}", (object) key, (object) request.Cookies[key.ToString()]));
      StringValues stringValues;
      //((StringValues) ref stringValues).\u002Ector(string.Join(";", (IEnumerable<string>) stringList));
      //if (((IDictionary<string, StringValues>) request.Headers()).ContainsKey("cookie"))
      //  request.Headers().set_Item("cookie", stringValues);
      //else
      //  ((IDictionary<string, StringValues>) request.Headers()).Add("cookie", stringValues);
    }

    public static long ConvertToUnixTime(DateTime time)
    {
      return (long) (time.ToUniversalTime() - new DateTime(1970, 1, 1, 0, 0, 0)).TotalSeconds;
    }

    public static long UnixTimeNow()
    {
      return Utils.ConvertToUnixTime(DateTime.Now);
    }

    private static Cookie ConvertToHttpCookie(JavaCookie cookie, string domain)
    {
      Cookie cookie1 = new Cookie(cookie.Name, cookie.Value)
      {
        Secure = cookie.Secure,
        Value = cookie.Value,
        Domain = string.IsNullOrEmpty(cookie.Domain) ? domain : cookie.Domain,
        HttpOnly = cookie.HttpOnly
      };
      if (cookie.MaxAge >= 0L)
        cookie1.Expires = DateTime.Now.AddSeconds((double) cookie.MaxAge);
      return cookie1;
    }
  }
}
