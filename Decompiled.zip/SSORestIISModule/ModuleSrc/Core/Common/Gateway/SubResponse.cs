﻿// Decompiled with JetBrains decompiler
// Type: SSORestIISModule.Core.Common.Gateway.SubResponse
// Assembly: SFTIHM.Filter_dotnetcore, Version=4.2.4.0, Culture=neutral, PublicKeyToken=null
// MVID: 138AA374-EEF4-489D-B4E8-554CE36F9300
// Assembly location: D:\SourceCode\GIT_NIKX\util\util-protector\assets\CSCore.dll

using System.Collections.Generic;

namespace SSORestIISModule.Core.Common.Gateway
{
  public class SubResponse
  {
    public int Status { get; set; }

    public Dictionary<string, string[]> Headers { get; set; }

    public List<JavaCookie> Cookies { get; set; }

    public string Body { get; set; }
  }
}
