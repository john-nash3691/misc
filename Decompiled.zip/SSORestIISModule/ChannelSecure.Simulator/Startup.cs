﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ChannelSecure.Simulator.Controllers;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ChannelSecure.Simulator
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddScoped<ChannelSecureRequestHandler>();

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.Use((cntxt, next) =>
            {
                if (cntxt.Request.Path == "/ssorest/gateway/evaluate")
                {
                    return Task.FromResult(new OkResult());
                }
                else if (cntxt.Request.Path == "/ssorest/service/gateway/evaluate")
                {
                    using (var scope = app.ApplicationServices.CreateScope())
                    {
                        return Task.FromResult(scope.ServiceProvider.GetService<ChannelSecureRequestHandler>().Handle(cntxt));
                    }
                }
                else if (cntxt.Request.Path == "/ssorest/alive.txt")
                {
                    return Task.FromResult(new OkResult());
                }

                return next();
            });
            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }
    }
}
