﻿using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using ChannelSecure.Simulator.Lib.Gateway;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.ResponseCaching.Internal;
using Newtonsoft.Json;

namespace ChannelSecure.Simulator
{
    public class ChannelSecureRequestHandler
    {
        public ChannelSecureRequestHandler()
        {

        }

        public async Task Handle(HttpContext context)
        {
            context.Response.StatusCode = 200;
            context.Response.ContentType = "application/json";
            var gr = new GatewayResponse();
            gr.Response = new SubResponse()
            {
                Body = "This is Body",
                Status = 100
            };
            gr.Request = new SubRequest();
            gr.Request.Headers = new Dictionary<string, string[]>();
            gr.Request.Headers.Add("MyKey", new[] { "MyValue" });

            await context.Response.WriteAsync(JsonConvert.SerializeObject(gr));
        }
    }
}