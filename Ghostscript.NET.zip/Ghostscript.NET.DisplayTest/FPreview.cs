﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ghostscript.NET.DisplayTest
{
    public partial class FPreview : Form
    {
        public FPreview()
        {
            InitializeComponent();

            this.Left = 0;
            this.Top = 0;
        }

        private void FPreview_Load(object sender, EventArgs e)
        {

        }
    }
}
